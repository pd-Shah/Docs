from django.apps import AppConfig


class VegetationquantitativeparameterConfig(AppConfig):
    name = 'vegetationquantitativeparameter'
