from persiantools.jdatetime import JalaliDate

from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from django.views import generic
from . import models
from django.contrib.auth.decorators import login_required
from .lib import engine

@login_required(login_url='/accounts/login/')
def home(request, ):
        return render(request=request,
                  template_name='vegetationquantitativeparameter/home.html',)


@login_required(login_url='/accounts/login/')
def ghazvin(request, ):
    object=get_object_or_404(models.Region, name='ghazvin')
    region_pk = object.id
    biomass_lai = models.BiomassLai.objects.filter(region=region_pk)
    et = models.Evapotranspiration.objects.filter(region=region_pk)

    context = {'biomass_lai': biomass_lai,
               'et':et,
               }
    persion_date=[]
    for obj in context['biomass_lai']:
         persion_date.append(JalaliDate(obj.date).strftime("%Y/%m/%d"))

    context['zip_date'] = zip(persion_date, context['biomass_lai'])

    return render(request=request,
                  context=context,
                  template_name='vegetationquantitativeparameter/et_lai_detail.html')
@login_required(login_url='/accounts/login/')
def moghan(request, ):
    object=get_object_or_404(models.Region, name='moghan')
    region_pk = object.id
    biomass_lai = models.BiomassLai.objects.filter(region=region_pk)
    et = models.Evapotranspiration.objects.filter(region=region_pk)

    context = {'biomass_lai': biomass_lai,
               'et':et,
               }
    return render(request=request,
                  context=context,
                  template_name='vegetationquantitativeparameter/et_lai_detail.html')

class BiomassLaiListView(generic.ListView):
    model = models.BiomassLai


class BiomassLaiDetailView(generic.DetailView):
    model = models.BiomassLai

    def get_queryset(self, ):
        engine.biomass_lai_connect_engine(self.kwargs['pk'])
        return models.BiomassLai.objects.all()


class RegionListView(generic.ListView):
    model = models.Region


class RegionDetailView(generic.DetailView):
    model = models.Region


class ETListView(generic.ListView):
    model = models.Evapotranspiration


class ETDetailView(generic.DetailView):
    model = models.Evapotranspiration

    def get_queryset(self, ):
        engine.evapotranspiration_connect_engine(self.kwargs['pk'])
        return models.Evapotranspiration.objects.all()
def signin(request, ):
    return render(request=request, template_name='vegetationquantitativeparameter/index.html')
def land(request, ):
    return render(request=request, template_name='vegetationquantitativeparameter/land.html')
