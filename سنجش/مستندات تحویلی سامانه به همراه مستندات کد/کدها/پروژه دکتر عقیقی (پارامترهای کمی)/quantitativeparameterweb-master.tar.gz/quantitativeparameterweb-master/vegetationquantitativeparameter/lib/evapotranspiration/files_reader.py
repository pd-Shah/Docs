import numpy as npy
import re
import pandas as pds

def find_index(pattern=None, text=None):

    pattern = 'GROUP = '
    text = '''
      GROUP = METADATA_FILE_INFO
        ORIGIN = "Image courtesy of the U.S. Geological Survey"
      END_GROUP = METADATA_FILE_INFO
           '''
    # Pre-compile the patterns
    regexes = [ re.compile(p) for p in [ 'GROUP = ',
                                         'END_GROUP = ',
                                         ]
                ]

    for regex in regexes:
        match=regex.search(text)
        if match:
            s = match.start()
            e = match.end()
            yield s,e


def convert_text_to_dict(file_name, file_directory):
    l=list()
    with open(file_directory+file_name) as txt:
        txt_obj=txt.readlines()
        for iteme in txt_obj:
            try:
                z=([i for i in iteme.split('=')])
                l.append((z[0].strip().replace('\"',""), z[1].strip().replace('\"',"")))
            except:
                pass

    return(dict(l))


def read_excel_as_dict(sheetname, file_name,  file_directory):
    excel_obj=pds.read_excel(file_directory+file_name, sheetname=sheetname, header=None)
    return dict(excel_obj.values)


def read_csv_as_numpy(file_name, directory_address):
    csv = npy.genfromtxt(directory_address+file_name, delimiter=",")
    return csv
