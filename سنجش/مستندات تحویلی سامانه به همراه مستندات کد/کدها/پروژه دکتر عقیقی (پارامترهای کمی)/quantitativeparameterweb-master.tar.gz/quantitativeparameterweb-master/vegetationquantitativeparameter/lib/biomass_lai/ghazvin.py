from .index.index import Index


class Maize():

    @staticmethod
    def lai(red_edge_6, red_edge_7, swir_1, narrow_nir, lai1, lai2, lai3, ):

        B7dB11 = Index.ratio_index(red_edge_7, swir_1)
        B8AdB11 = Index.ratio_index(narrow_nir, swir_1)
        B6B8A = Index.ratio_index(red_edge_6, narrow_nir)

        lai_maize1 = Index.lai(B7dB11, lai1[0], lai1[1])
        lai_maize2 = Index.lai(B8AdB11, lai2[0], lai2[1])
        lai_maize3 = Index.lai(B6B8A, lai3[0], lai3[1])

        return lai_maize1, lai_maize2, lai_maize3

    @staticmethod
    def wet_biomass(narrow_nir, swir_1, nir, red_edge_7, wet1, wet2, wet3, ):

        B8AdB11 = Index.ratio_index(red_edge_7, swir_1)
        B8dB11 = Index.ratio_index(narrow_nir, swir_1)
        B7dB11 = Index.ratio_index(red_edge_7, swir_1)

        wet_biomass_maize1 = Index.wet_biomass(B8AdB11, wet1[0], wet1[1])
        wet_biomass_maize2 = Index.wet_biomass(B8dB11, wet2[0], wet2[1])
        wet_biomass_maize3 = Index.wet_biomass(B7dB11, wet3[0], wet3[1])

        return wet_biomass_maize1, wet_biomass_maize2, wet_biomass_maize3

    @staticmethod
    def dry_biomass(red_edge_6, nir, red_edge_7, narrow_nir,
                    swir_1, dry1, dry2, dry3,):

        B6B8 = Index.diff_index(red_edge_6, nir)
        B6B8A = Index.diff_index(red_edge_6, narrow_nir)
        B7B11 = Index.diff_index(red_edge_7, swir_1)

        dry_biomass_maize1 = Index.dry_biomass(B6B8, dry1[0], dry1[1])
        dry_biomass_maize2 = Index.dry_biomass(B6B8A, dry2[0], dry2[1])
        dry_biomass_maize3 = Index.dry_biomass(B7B11, dry3[0], dry3[1])

        return dry_biomass_maize1, dry_biomass_maize2, dry_biomass_maize3


class Alfalfa():

    @staticmethod
    def lai(narrow_nir, swir1, red_edge_7, lai1, lai2, lai3, ):

        B8AdB11 = Index.ratio_index(narrow_nir, swir1)
        NB8AB11 = Index.normalized_index(red_edge_7, swir1)
        NB7B11 = Index.normalized_index(red_edge_7, swir1)

        lai_alfalfa1 = Index.lai(B8AdB11, lai1[0], lai1[1])
        lai_alfalfa2 = Index.lai(NB8AB11, lai2[0], lai2[1])
        lai_alfalfa3 = Index.lai(NB7B11, lai3[0], lai3[1])

        return lai_alfalfa1, lai_alfalfa2, lai_alfalfa3

    @staticmethod
    def wet_biomass(narrow_nir, swir1, swir2, red_edge_7, wet1, wet2, wet3, ):

        B8AdB11 = Index.ratio_index(narrow_nir, swir1)
        B7dB11 = Index.ratio_index(red_edge_7, swir1)
        B7dB12 = Index.ratio_index(red_edge_7, swir2)

        wet_biomass_alfalfa1 = Index.wet_biomass(B8AdB11, wet1[0], wet1[1])
        wet_biomass_alfalfa2 = Index.wet_biomass(B7dB11, wet2[0], wet2[1])
        wet_biomass_alfalfa3 = Index.wet_biomass(B7dB12, wet3[0], wet3[1])

        return wet_biomass_alfalfa1, wet_biomass_alfalfa2, wet_biomass_alfalfa3

    @staticmethod
    def dry_biomass(red_edge_5, nir, red, dry1, dry2, dry3, ):

        B5B8 = Index.diff_index(red_edge_5, nir)
        NDREI = Index.ndrei(nir, red_edge_5)
        EVI = Index.evi(nir, red)

        dry_biomass_alfalfa1 = Index.dry_biomass(B5B8, dry1[0], dry1[1])
        dry_biomass_alfalfa2 = Index.dry_biomass(NDREI, dry2[0], dry2[1])
        dry_biomass_alfalfa3 = Index.dry_biomass(EVI, dry3[0], dry3[1])

        return dry_biomass_alfalfa1, dry_biomass_alfalfa2, dry_biomass_alfalfa3


class Ghazvin(Maize, Alfalfa):
    def run(self,
            blue,
            green,
            narrow_nir,
            nir,
            red,
            red_edge_5,
            red_edge_6,
            red_edge_7,
            swir_1,
            swir_2,
            alfalfa_dry1,
            alfalfa_dry2,
            alfalfa_dry3,
            alfalfa_lai1,
            alfalfa_lai2,
            alfalfa_lai3,
            alfalfa_wet1,
            alfalfa_wet2,
            alfalfa_wet3,
            maize_dry1,
            maize_dry2,
            maize_dry3,
            maize_lai1,
            maize_lai2,
            maize_lai3,
            maize_wet1,
            maize_wet2,
            maize_wet3):

        alfalfa_dry_biomass = Alfalfa.dry_biomass(
                                    red_edge_5=red_edge_5,
                                    nir=nir,
                                    red=red,
                                    dry1=alfalfa_dry1,
                                    dry2=alfalfa_dry2,
                                    dry3=alfalfa_dry3,
        )

        alfalfa_lai = Alfalfa.lai(
                                        narrow_nir=narrow_nir,
                                        swir1=swir_1,
                                        red_edge_7=red_edge_7,
                                        lai1=alfalfa_lai1,
                                        lai2=alfalfa_lai2,
                                        lai3=alfalfa_lai3,
        )

        alfalfa_wet_biomass = Alfalfa.wet_biomass(
                                        narrow_nir=narrow_nir,
                                        swir1=swir_1,
                                        swir2=swir_2,
                                        red_edge_7=red_edge_7,
                                        wet1=alfalfa_wet1,
                                        wet2=alfalfa_wet2,
                                        wet3=alfalfa_wet3,
        )

        maize_dry_biomass = Maize.dry_biomass(
                                            red_edge_6=red_edge_6,
                                            nir=nir,
                                            red_edge_7=red_edge_7,
                                            narrow_nir=narrow_nir,
                                            swir_1=swir_1,
                                            dry1=maize_dry1,
                                            dry2=maize_dry2,
                                            dry3=maize_dry3,
        )

        maize_lai = Maize.lai(
                                  red_edge_6=red_edge_6,
                                  red_edge_7=red_edge_7,
                                  swir_1=swir_1,
                                  narrow_nir=narrow_nir,
                                  lai1=maize_lai1,
                                  lai2=maize_lai2,
                                  lai3=maize_lai3,
        )

        maize_wet_biomass = Maize.wet_biomass(
                                            narrow_nir=narrow_nir,
                                            swir_1=swir_1,
                                            nir=nir,
                                            red_edge_7=red_edge_7,
                                            wet1=maize_wet1,
                                            wet2=maize_wet2,
                                            wet3=maize_wet3,
        )

        return {
                'alfalfa_dry_biomass': alfalfa_dry_biomass,
                'alfalfa_lai': alfalfa_lai,
                'alfalfa_wet_biomass': alfalfa_wet_biomass,
                'maize_dry_biomass': maize_dry_biomass,
                'maize_lai': maize_lai,
                'maize_wet_biomass': maize_wet_biomass,
        }
