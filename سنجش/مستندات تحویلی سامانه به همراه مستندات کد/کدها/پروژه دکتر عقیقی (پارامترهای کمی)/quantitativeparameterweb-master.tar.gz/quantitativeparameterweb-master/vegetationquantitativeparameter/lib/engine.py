import numpy as np
import rasterio
import importlib
from matplotlib import pyplot as plt

from django.conf import settings
from django.shortcuts import get_object_or_404

from vegetationquantitativeparameter import models
from .evapotranspiration import main_metric, main_sebal
from .evapotranspiration.load_data import FileDir
from .machinlearning import main as mach_learn


def evapotranspiration_connect_engine(pk, ):
    selected_object = get_object_or_404(models.Evapotranspiration, pk=pk)

    if not selected_object.result_metric:
        input_data = FileDir(root=selected_object.root,
                             ground_data=selected_object.ground_data,
                             band2=selected_object.band2,
                             band3=selected_object.band3,
                             band4=selected_object.band4,
                             band5=selected_object.band5,
                             band6=selected_object.band6,
                             band7=selected_object.band7,
                             band10=selected_object.band10,
                             band11=selected_object.band11,
                             meta=selected_object.meta,
                             fmask=selected_object.fmask,
                             dem=selected_object.dem,
                             land_cover=selected_object.land_cover,
                             slope=selected_object.slope,
                             aspect=selected_object.aspect)

        metric = main_metric.main_metric(FileDir=input_data)
        # metric = metric.reshape((1, metric.shape[0], metric.shape[1]))

        path = '{0}/VegetationQuantitativeParameterApp/Regions/{1}/Analyzes/{2}/result_metric.jpg'.format(
                       settings.MEDIA_ROOT, selected_object.region.name, selected_object.id
              )

        plt.imsave(path, metric)

        path = 'VegetationQuantitativeParameterApp/Regions/{0}/Analyzes/{1}/result_metric.jpg'.format(
                       selected_object.region.name, selected_object.id
              )

        selected_object.result_metric = path

        sebal = main_sebal.main_sebal(FileDir=input_data)
        # sebal = sebal.reshape((1, sebal.shape[0], sebal.shape[1]))

        path = '{0}/VegetationQuantitativeParameterApp/Regions/{1}/Analyzes/{2}/result_sebal.jpg'.format(
                       settings.MEDIA_ROOT, selected_object.region.name, selected_object.id
              )

        plt.imsave(path, sebal)

        path = 'VegetationQuantitativeParameterApp/Regions/{0}/Analyzes/{1}/result_sebal.jpg'.format(
                       selected_object.region.name, selected_object.id
              )
        selected_object.result_sebal = path
        selected_object.save()

        return True


def save_file_biomass_lai(analyze, result_dict, file_name, dict_index):
    path = '{0}/VegetationQuantitativeParameterApp/Regions/{1}/Analyzes/{2}/{3}.jpg'.format(
               settings.MEDIA_ROOT, analyze.region.name, analyze.id, file_name
          )
    result = result_dict[dict_index][0]
    # result = result.reshape((1, result.shape[0], result.shape[1]))

    # with rasterio.open(path, 'w', driver='GTiff',
    #                    height=result.shape[1],
    #                    width=result.shape[2],
    #                    count=result.shape[0],
    #                    crs='+proj=latlong',
    #                    dtype=rasterio.int32) as dst:
    #     dst.write(result.astype(np.int32))

    plt.imsave(path, result)

    path = 'VegetationQuantitativeParameterApp/Regions/{0}/Analyzes/{1}/{2}.jpg'.format(
                   analyze.region.name, analyze.id, file_name
          )
    return path


def biomass_lai_connect_engine(pk, ):
    analyze = get_object_or_404(models.BiomassLai, pk=pk)

    # dynamic load package
    lib_dir = analyze.region.name.split('_')
    class_name = lib_dir[-1].title()
    class_dir = 'vegetationquantitativeparameter.lib.biomass_lai.' + '.'.join(lib_dir)
    module = importlib.import_module(class_dir)
    klass = getattr(module, class_name)

    if not analyze.alfalfa_dry_biomass_result:
        blue_path = analyze.get_blue_path()
        green_path = analyze.get_green_path()
        narrow_nir_path = analyze.get_narrow_nir_path()
        nir_path = analyze.get_nir_path()
        red_path = analyze.get_red_path()
        red_edge_5_path = analyze.get_red_edge_5_path()
        red_edge_6_path = analyze.get_red_edge_6_path()
        red_edge_7_path = analyze.get_red_edge_7_path()
        swir_1_path = analyze.get_swir_1_path()
        swir_2_path = analyze.get_swir_2_path()

        print("reading files...")
        with rasterio.open(blue_path) as src:
            blue = src.read(1).astype(np.float)

        with rasterio.open(green_path) as src:
            green = src.read(1).astype(np.float)

        with rasterio.open(narrow_nir_path) as src:
            narrow_nir = src.read(1).astype(np.float)

        with rasterio.open(nir_path) as src:
            nir = src.read(1).astype(np.float)

        with rasterio.open(red_path) as src:
            red = src.read(1).astype(np.float)

        with rasterio.open(red_edge_5_path) as src:
            red_edge_5 = src.read(1).astype(np.float)

        with rasterio.open(red_edge_6_path) as src:
            red_edge_6 = src.read(1).astype(np.float)

        with rasterio.open(red_edge_7_path) as src:
            red_edge_7 = src.read(1).astype(np.float)

        with rasterio.open(swir_1_path) as src:
            swir_1 = src.read(1).astype(np.float)

        with rasterio.open(swir_2_path) as src:
            swir_2 = src.read(1).astype(np.float)
        print('done!')

        obj = klass()

        result_dict = getattr(obj, 'run')(
                        blue=blue,
                        green=green,
                        narrow_nir=narrow_nir,
                        nir=nir,
                        red=red,
                        red_edge_5=red_edge_5,
                        red_edge_6=red_edge_6,
                        red_edge_7=red_edge_7,
                        swir_1=swir_1,
                        swir_2=swir_2,
                        alfalfa_dry1=analyze.alfalfa_dry['1'],
                        alfalfa_dry2=analyze.alfalfa_dry['2'],
                        alfalfa_dry3=analyze.alfalfa_dry['3'],
                        alfalfa_lai1=analyze.alfalfa_lai['1'],
                        alfalfa_lai2=analyze.alfalfa_lai['2'],
                        alfalfa_lai3=analyze.alfalfa_lai['3'],
                        alfalfa_wet1=analyze.alfalfa_wet['1'],
                        alfalfa_wet2=analyze.alfalfa_wet['2'],
                        alfalfa_wet3=analyze.alfalfa_wet['3'],
                        maize_dry1=analyze.maize_dry['1'],
                        maize_dry2=analyze.maize_dry['2'],
                        maize_dry3=analyze.maize_dry['3'],
                        maize_lai1=analyze.maize_lai['1'],
                        maize_lai2=analyze.maize_lai['2'],
                        maize_lai3=analyze.maize_lai['3'],
                        maize_wet1=analyze.maize_wet['1'],
                        maize_wet2=analyze.maize_wet['2'],
                        maize_wet3=analyze.maize_wet['3'],
        )

        analyze.alfalfa_dry_biomass_result = save_file_biomass_lai(
                analyze,
                result_dict,
                'alfalfa_dry_biomass_result',
                'alfalfa_dry_biomass',
        )

        analyze.alfalfa_lai_result = save_file_biomass_lai(
                analyze,
                result_dict,
                'alfalfa_lai_result',
                'alfalfa_lai',
        )

        analyze.alfalfa_wet_biomass_result = save_file_biomass_lai(
                analyze,
                result_dict,
                'alfalfa_wet_biomass_result',
                'alfalfa_wet_biomass',
        )

        analyze.maize_dry_biomass_result = save_file_biomass_lai(
                analyze,
                result_dict,
                'maize_dry_biomass_result',
                'maize_dry_biomass',
        )

        analyze.maize_lai_result = save_file_biomass_lai(
                analyze,
                result_dict,
                'maize_lai_result',
                'maize_lai',
        )

        analyze.maize_wet_biomass_result = save_file_biomass_lai(
                analyze,
                result_dict,
                'maize_wet_biomass_result',
                'maize_wet_biomass',
        )

        '''
        run machinlearning
        '''
        alfalfa_dry_biomass = mach_learn.alfalfa_dry_biomass(red_edge_5, nir, red, result_dict['alfalfa_dry_biomass'][0].astype(np.int32))
        alfalfa_dry_biomass_dic = {}
        alfalfa_dry_biomass_dic['decesition_tree'] = alfalfa_dry_biomass['decesition_tree']
        alfalfa_dry_biomass_dic['gussian_process_regresion'] = alfalfa_dry_biomass['gussian_process_regresion']
        alfalfa_dry_biomass_dic['random_forest'] = alfalfa_dry_biomass['random_forest']
        alfalfa_dry_biomass_dic['svr'] = alfalfa_dry_biomass['svr']

        alfalfa_lai = mach_learn.alfalfa_lai(narrow_nir, swir_1, red_edge_7, result_dict['alfalfa_lai'][0].astype(np.int32))
        alfalfa_lai_dic = {}
        alfalfa_lai_dic['decesition_tree'] = alfalfa_lai['decesition_tree']
        alfalfa_lai_dic['gussian_process_regresion'] = alfalfa_lai['gussian_process_regresion']
        alfalfa_lai_dic['random_forest'] = alfalfa_lai['random_forest']
        alfalfa_lai_dic['svr'] = alfalfa_lai['svr']

        alfalfa_wet_biomass = mach_learn.alfalfa_wet_biomass(narrow_nir, swir_1, swir_2, red_edge_7, result_dict['alfalfa_wet_biomass'][0].astype(np.int32))
        alfalfa_wet_biomass_dict = {}
        alfalfa_wet_biomass_dict['decesition_tree'] = alfalfa_wet_biomass['decesition_tree']
        alfalfa_wet_biomass_dict['gussian_process_regresion'] = alfalfa_wet_biomass['gussian_process_regresion']
        alfalfa_wet_biomass_dict['random_forest'] = alfalfa_wet_biomass['random_forest']
        alfalfa_wet_biomass_dict['svr'] = alfalfa_wet_biomass['svr']

        maize_dry_biomass = mach_learn.maize_dry_biomass(red_edge_6, red_edge_7, nir, narrow_nir, swir_1, result_dict['maize_dry_biomass'][0].astype(np.int32))
        maize_dry_biomass_dict = {}
        maize_dry_biomass_dict['decesition_tree'] = maize_dry_biomass['decesition_tree']
        maize_dry_biomass_dict['gussian_process_regresion'] = maize_dry_biomass['gussian_process_regresion']
        maize_dry_biomass_dict['random_forest'] = maize_dry_biomass['random_forest']
        maize_dry_biomass_dict['svr'] = maize_dry_biomass['svr']

        maize_lai = mach_learn.maize_lai(red_edge_6, red_edge_7, swir_1, narrow_nir, result_dict['maize_lai'][0].astype(np.int32))
        maize_lai_dict = {}
        maize_lai_dict['decesition_tree'] = maize_lai['decesition_tree']
        maize_lai_dict['gussian_process_regresion'] = maize_lai['gussian_process_regresion']
        maize_lai_dict['random_forest'] = maize_lai['random_forest']
        maize_lai_dict['svr'] = maize_lai['svr']

        maize_wet_biomass = mach_learn.maize_wet_biomass(swir_1, narrow_nir, nir, red_edge_7, result_dict['maize_wet_biomass'][0].astype(np.int32))
        maize_wet_biomass_dict = {}
        maize_wet_biomass_dict['decesition_tree'] = maize_wet_biomass['decesition_tree']
        maize_wet_biomass_dict['gussian_process_regresion'] = maize_wet_biomass['gussian_process_regresion']
        maize_wet_biomass_dict['random_forest'] = maize_wet_biomass['random_forest']
        maize_wet_biomass_dict['svr'] = maize_wet_biomass['svr']

        machinlearning_score = {}
        machinlearning_score['alfalfa_dry_biomass'] = alfalfa_dry_biomass_dic
        machinlearning_score['alfalfa_lai'] = alfalfa_lai_dic
        machinlearning_score['alfalfa_wet_biomass'] = alfalfa_wet_biomass_dict
        machinlearning_score['maize_dry_biomass'] = maize_dry_biomass_dict
        machinlearning_score['maize_lai'] = maize_lai_dict
        machinlearning_score['maize_wet_biomass'] = maize_wet_biomass_dict

        analyze.machinlearning_score = machinlearning_score

        analyze.save()

        return True
