import numpy as np


class Base():

    @staticmethod
    def index_v1(band1, band2):
        '''
        Calculate ci edge Index
            Inputs: Band1 , Band2.
            Outputs: ci Index (Double or float)

        Equivalent to this functions in matlab
            CIgreen_Func
            CIrededge_Func
        '''
        nomin = band1 / band2
        ci = nomin-1
        ci[nomin == 0] = 0
        return ci

    @staticmethod
    def index_v2(band1, band2):
        nomin = band1 - band2
        den_nomin = band1 + band2
        result = nomin / den_nomin
        result[den_nomin == 0] = 0
        return result

    @staticmethod
    def index_v3(index, s, intercept):
        dry_biomass = s * index + intercept
        dry_biomass[dry_biomass < 0] = 0
        return dry_biomass

    @staticmethod
    def index_v4(bst_index, s, intercept):
        return np.absolute(s * bst_index + intercept)
