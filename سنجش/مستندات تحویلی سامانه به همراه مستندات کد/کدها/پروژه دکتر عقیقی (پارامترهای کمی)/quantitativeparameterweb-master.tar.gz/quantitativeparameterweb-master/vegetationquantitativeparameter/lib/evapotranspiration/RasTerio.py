import rasterio
import rasterio.features
import rasterio.warp
from matplotlib import pyplot as plt
import numpy as np
from osgeo import gdal

def raster_information(dataset):
    # Read the dataset's valid data mask as a ndarray.
    mask = dataset.dataset_mask()

    # Extract feature shapes and values from the array.
    for geom, val in rasterio.features.shapes(
            mask, transform=dataset.transform):

        # Transform shapes from the dataset's own coordinate
        # reference system to CRS84 (EPSG:4326).
        geom = rasterio.warp.transform_geom(
            dataset.crs, 'EPSG:4326', geom, precision=6)

        # Print GeoJSON shapes to stdout.
        print(geom)

def read_write():
    with rasterio.open('inputfiles/test.tif') as dataset:
        raster_information(dataset)
        print(dataset.bounds)
        band1=dataset.read(1)
        print(band1)

        #index of x,y in array
        xy=dataset.index(dataset.bounds.left, dataset.bounds.top)
        print(xy)

        x= 0.00031456531 + dataset.bounds.left
        y=-0.00031456531 + dataset.bounds.top
        x,y=dataset.index(x,y)
        print(x,y,band1[x,y])
        band1=band1[100: , 300:]
        with rasterio.open("new.tif",'w', driver='GTiff', width=band1.shape[0],\
                           height=band1.shape[1], count=1, dtype= band1.dtype,\
                           ) as wdataset:
            wdataset.write_band(1,band1)

def test():
    print(rasterio.__version__)
    dataset=rasterio.open("LC08_L1TP_165035_20170630_20170630_01_RT_B3.TIF")
    print(type(dataset))
    print(dataset.transform)
    print(dataset.count)
    print(dataset.width, dataset.height)
    print(dataset.shape)
    print(dataset.bounds)
    print(dataset.crs)
    print(dataset.indexes)
    band_one=dataset.read(1)
    print(band_one)
    #top-left
    xll = 47.50
    yll = 39.65
    #bottom-down
    xrd = 48.083
    yrd = 39.420
    t_r, t_c= dataset.index(xll, yll)
    b_r, b_c= dataset.index(xrd, yrd)
    #print(band_one[r,c])
    # print(dataset.xy(r,c))
    # print(dataset.tags())
    #print(dataset[not dataset.dataset_mask()==255])

    plt.imshow(band_one ,cmap='Greys_r')
    plt.show()
    plt.imshow(band_one, cmap='pink')
    plt.show()
    plt.imshow(band_one[t_r:b_r, t_c:b_c], cmap="pink")
    plt.show()
    print(band_one.shape, (1612, 3121))
    print(dataset.index(47.802, 39.573))
    print(band_one[768, 1066])

def raster_plot(array):
    plt.imshow(array)
    plt.show()

def checkmask(longs, lats):
    dataset=rasterio.open("LC08_L1TP_165035_20170630_20170630_01_RT_B2.TIF")
    r,c=dataset.index(longs, lats)
    print(dataset)
    x,y=dataset.index(longs+50000, lats)
    radius=abs(c-y)+1
    print(r, c)
    dataset=dataset.read(1)
    print(dataset[r,c])

def read_raster_as_array(file_name, directory_address, band=1):
    with rasterio.open(directory_address+file_name) as dataset:
        band_array=dataset.read(band)
    return band_array.astype(float)

def read_as_raster(file_name, directory_address):
    with rasterio.open(directory_address+file_name) as dataset:
        raster=dataset
    return raster

def calculate_slope(file_name, directory_address):
    DEM=directory_address+file_name
    option=gdal.DEMProcessingOptions()
    gdal.DEMProcessing('slope.tif', DEM, 'slope', slopeFormat='degree', alg='ZevenbergenThorne')
    with rasterio.open('slope.tif') as dataset:
        slope=dataset.read(1)
    return slope

def calculate_aspect(file_name, directory_address):
    DEM=directory_address+file_name
    gdal.DEMProcessing('aspect.tif', DEM, 'aspect', trigonometric=False, zeroForFlat=True, alg='ZevenbergenThorne')
    with rasterio.open('aspect.tif') as dataset:
        print(dataset.shape)
        aspect=dataset.read(1)
    return aspect

if __name__=="__main__":
    slope=calculate_slope('DEM.tif')
    aspect=calculate_aspect('DEM.tif')

    print(type(slope))
    print(slope.dtype)
    print(slope.shape)
    print(slope)
