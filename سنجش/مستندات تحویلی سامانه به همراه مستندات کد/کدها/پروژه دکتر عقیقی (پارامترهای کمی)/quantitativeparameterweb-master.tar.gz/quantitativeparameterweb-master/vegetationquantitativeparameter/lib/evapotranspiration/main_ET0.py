import load_data as ld
from math import pi, cos, sin, exp
import math

param = ld.ET_10_Params()
bands = ld.Band()
DEM=bands.dem


# Stefan-Boltzmann constant [MJ K-4 m-2 day-1]
sig = 4.903 * 10 ** (-9)
# Emissivity: normally more than 95%
Emiss = 0.97
# Albedo for reference ET
albedo = 0.23
Tcold = param.Tmin + 273
Tmean = (param.Tmax + param.Tmin) / 2
Tdew = (112 + 0.9 * param.Tmean) * param.RH ** 0.125 + (0.1 * param.Tmean - 112)
dT = abs(param.Tmax - param.Tmin)
date = '20170527'
dr = 1 + 0.033 * cos(DOY * 2 * pi / 365)
h = param.hr + param.Min / 60
# mean saturation vapour preature (kPa)
SatPr = 0.6108 * exp((17.27 * Tmean) / (Tmean + 237.3))
# Slope of sauration vapour preture curve
delta = (4098 * SatPr) / (param.Tmean+237.3) ** 2
# actual vapour preature (kPa)
ActPr = 0.6108 * exp((17.27 * Tdew) / (Tdew + 237.3))
# y = (1.013*10^-3* P)/(0.622*2.45) = 0.665*10^-3*P  Psychrometric Constant
y = param.P * 0.665 * 10 ** (-3)
