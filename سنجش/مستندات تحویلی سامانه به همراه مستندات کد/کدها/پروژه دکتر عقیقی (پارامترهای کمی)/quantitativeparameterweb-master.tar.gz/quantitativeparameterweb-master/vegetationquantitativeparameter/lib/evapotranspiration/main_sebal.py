import  numpy          as np
from warnings import warn
from math     import pi

from . import  rs_mathematica as rs
from . import  load_data      as ld
from .RasTerio import raster_plot

def main_sebal(FileDir, ):

    # TODO: UI
    Zwin=2
    Zveg = 0.5
    Agri_code = 10
    selectmethod= "1"
    selectband=   "10"
    InstAtmTransmiss=0.82
    AtmTransmiss24=0.75

    Meta= ld.META(FileDir)
    param= ld.Param(FileDir)
    Radiance= ld.Radiance(FileDir)
    Reflectance= ld.Reflectance(FileDir)
    w= ld.WeightingCoefficient()
    cs= ld.Constants()

    bands= ld.Band(FileDir)
    Band2= bands.band2
    Band3= bands.band3
    Band4= bands.band4
    Band5= bands.band5
    Band6= bands.band6
    Band7= bands.band7
    Band10= bands.band10
    Band11= bands.band11
    DEM= bands.dem
    LandCover= bands.land_cover
    fmask= bands.fmask

    albedotoa= rs._albedo_top_atmosphere(w.band2, Reflectance.band2, w.band3, Reflectance.band3, w.band4, Reflectance.band4, w.band5, Reflectance.band5, w.band6, Reflectance.band6, w.band7, Reflectance.band7)

    AtmosphericTransmissivity= rs.Transmissivity(DEM)
    albedo= rs._albedo(albedotoa, AtmosphericTransmissivity)
    NDVI=np.real(rs.ndvii(Reflectance.band5, Reflectance.band4))
    maxNDVI= np.max(NDVI)
    NDWI6= rs._NDWI(Reflectance.band5, Reflectance.band6)
    NDWI7= rs._NDWI(Reflectance.band5, Reflectance.band7)

    #estimation Emissivity of ground surface
    Emissiv_1= rs.emissivity1(NDVI)
    Emissiv_210= rs.emissivity210(NDVI)
    Emissiv_211= rs.emissivity211(NDVI)

    NDVImin = np.max(NDVI)    # Maximum of NDVI
    NDVImax = np.min(NDVI)    # Maximum of NDVI
    vegetationfraction= rs._vegetation_fraction(NDVI, NDVImin, NDVImax)
    Cavity10= rs._cavity(cs.Es10, cs.Ev10, cs.Fprim, vegetationfraction)
    Cavity11= rs._cavity(cs.Es11, cs.Ev11, cs.Fprim, vegetationfraction)

    emissivity11= rs._emissivity3_11(NDVI, vegetationfraction, cs.Es11, Cavity11, Reflectance.band4, cs.Ev11)
    emissivity10= rs._emissivity3_10(NDVI, vegetationfraction, cs.Es10, Cavity10, Reflectance.band4, cs.Ev10)

    #LST estimation
    if selectmethod=="0":
        LandSurfaceTemperature10= rs.lst10(Emissiv_1, Radiance.band10, Meta.k1b10, Meta.k2b10)
        LandSurfaceTemperature11= rs.lst11(Emissiv_1, Radiance.band11, Meta.k1b11, Meta.k2b11)

        if selectband=="10":
            LST= LandSurfaceTemperature10
            Emissivity= Emissiv_1

        elif selectband=="11":
            LST= LandSurfaceTemperature11
            Emissivity= Emissiv_1

        else:
            warn("selected band is out of range.")

    elif selectmethod=="1":
        LandSurfaceTemperature101= rs.lst10(emissivity10, Radiance.band10, Meta.k1b10, Meta.k2b10)
        LandSurfaceTemperature111= rs.lst11(emissivity11, Radiance.band11, Meta.k1b11, Meta.k2b11)

        if selectband=="10":
            LST= LandSurfaceTemperature101
            Emissivity= emissivity10

        elif selectband=="11":
            LST= LandSurfaceTemperature111
            Emissivity= emissivity11

        else:
            warn("selected band is out of range.")

    elif selectmethod=="2":
        BT10= rs._BT(Meta.k2b10, Meta.k1b10, Radiance.band10)
        BT11= rs._BT(Meta.k2b11, Meta.k1b11, Radiance.band11)
        #LST estimation
        LandSurfaceTemperature102= rs.lst102(BT10, emissivity10)
        LandSurfaceTemperature112= rs.lst112(BT11, emissivity11)

        if selectband=="10":
            LST= LandSurfaceTemperature102
            Emissivity= emissivity10

        elif selectband=="11":
            LST= LandSurfaceTemperature112
            Emissivity= emissivity11

        else:
            warn("selected band is out of range.")

    elif selectmethod=="3":
        BT10= rs._BT(Meta.k2b10, Meta.k1b10, Radiance.band10)
        BT11= rs._BT(Meta.k2b11, Meta.k1b11, Radiance.band11)
        #LST estimation
        LandSurfaceTemperature103=rs.lst102(BT10, Emissiv_210)
        LandSurfaceTemperature113=rs.lst112(BT11, Emissiv_211)

        if selectband=="10":
            LST= LandSurfaceTemperature103
            Emissivity= Emissiv_210

        elif selectband=="11":
            LST= LandSurfaceTemperature113
            Emissivity= Emissiv_211

        else:
            warn("selected band is out of range.")

    else:
        warn("selected method is out of range.")

    #LongWave Outcome Radiation in watt/m2
    LongWaveOutward = rs.LongWaveOut(Emissivity, LST)

    #LST cold and hot pixel (ESA method)
    LSThot_ESA =  rs.lsthotesa(LST, LandCover, albedo, NDVI, fmask, NDVI.shape[0], NDVI.shape[1], Agri_code, param, FileDir)

    LSTcold_ESA = rs.lstcoldesa(LST,LandCover, albedo, NDVI, fmask, NDVI.shape[0], NDVI.shape[1], Agri_code, param, FileDir)

    #LongWave Income Radiation in watt/m2
    LongWaveInward = rs.LongWaveIncome(AtmosphericTransmissivity, LSTcold_ESA)

    #ShortWave Income Radiation in watt/m2
    ShortWaveRadiation = rs.ShortWaveIncome(Meta.zenith, AtmosphericTransmissivity, Meta.dr)

    #Net Radiation
    Rn = np.real( rs.NetRadiation( albedo, ShortWaveRadiation, LongWaveInward, LongWaveOutward, Emissivity))

    LAI = rs.LeafAreaIndex(NDVI)

    #Soil Heat Flux Calculation
    GroundHeat = rs.GroundFlux (LST, albedo, NDVI, Rn)
    Zom= rs.MomentumRoughnessLength(NDVI, albedo, LAI)

    #First step for calculating sensible heat flux
    #Friction Velocity at station
    Friction_station= rs.FrictionStation(param.WindSpeed, Zwin, Zveg)
    wind200 = rs.WindSpeed200(Friction_station, Zom)

    #Aerodynamic Resistance
    Rah = np.real(rs.AerodynamicResistance(Friction_station))

    #Air Pressure at 20 Celsius degress temperature
    AirPressure20 = rs.AirPressure20Degrees(DEM)

    AirDensity= rs.AirDensity(AirPressure20, LST)

    #Friction Velocity at land surface
    Friction= rs.FrictionVelocity(wind200, Zom)

    #Hhot,dThot
    h_hot= Rn - GroundHeat
    dThot= rs.dThott(AirDensity, Rah, h_hot, LST, LSThot_ESA)
    dThotold = dThot
    dTcold = 0


    slope= rs.slopea(dThot, dTcold, LSThot_ESA, LSTcold_ESA)
    offset= rs.offsett(slope, dThot, LSThot_ESA)
    dT= rs.d_T(slope, LST, offset)
    H= rs.SensibleHeatFlux(AirDensity, dT, Rah)
    L= rs.MoninObukhovLength(AirDensity, LST, Friction, H)
    PSI200= rs.PSI_200(L)
    PSI2= rs.PSI_2(L)
    PSI1= rs.PSI_1(L)

    HT1=rs._HT_1(PSI1, L)
    HT200=rs._HT200(L, PSI200, pi)
    HT2=rs._HT2(L, PSI2)
    Friction=rs._Friction(L, wind200, Zom, HT200)
    Rah=rs._Rah(L, HT2, HT1, Friction)
    ##end of for loop in matlab

    dThot= rs.dThott(AirDensity, Rah, h_hot, LST, LSThot_ESA)
    dTcold = 0;
    slope= rs.slopea(dThot, dTcold, LSThot_ESA, LSTcold_ESA)
    offset= rs.offsett(slope, dThot, LSThot_ESA)
    dT= rs.d_T(slope, LST, offset)
    H= rs.SensibleHeatFlux(AirDensity, dT, Rah)
    dThotcurrent = dThot

    #Sensible Heat Flux Calculation (H calculation)
    while abs(dThotcurrent - dThotold) > 0.5:
        L= rs.MoninObukhovLength(AirDensity, LST, Friction, H)
        PSI200=rs.PSI_200(L)
        PSI2= rs.PSI_2(L)
        PSI1= rs.PSI_1(L)

        #nested loop
        HT1=rs._HT_1(PSI1, L)
        HT200=rs._HT200(L, PSI200, pi)
        HT2=rs._HT2(L, PSI2)
        Friction=rs._Friction(L, wind200, Zom, HT200)
        Rah=rs._Rah(L, HT2, HT1, Friction)

        dThotold = dThot
        dThot = rs.dThott(AirDensity, Rah, h_hot, LST, LSThot_ESA)
        dTcold = 0
        slope= rs.slopea(dThot, dTcold, LSThot_ESA, LSTcold_ESA)
        offset= rs.offsett(slope, dThot, LSThot_ESA)
        dT= rs.d_T(slope, LST, offset)
        H=  rs.SensibleHeatFlux(AirDensity, dT, Rah)
        dThotcurrent= dThot

    # Computation of Latenet heat flux, instantaneous ET and Daily ET
    evapo_fric= rs.EvaporativeFriction(Rn, H, GroundHeat)
    vapor_latent= rs._vapor_latent(LST)
    Rn24= rs.netrad24(param, Meta, albedo, InstAtmTransmiss, AtmTransmiss24)
    ET24= rs.Evapot24(evapo_fric, Rn24, vapor_latent)

    return ET24

    # TODO: Save and Write outputs
    # raster_plot(ET24)
    # raster_plot(LST)
    # raster_plot(Rn)
    # raster_plot(albedo)
    # raster_plot(NDVI)
