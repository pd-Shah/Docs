import numpy as np
from math import pi, log
import rasterio
from skimage import morphology
from scipy.ndimage.filters import generic_filter
from math import tan, exp
from scipy.signal import convolve2d
import functools
import matplotlib.pyplot as plt
from .load_data import FileDir, META
import utm

def AerodynamicResistance(Friction) :
    '''
        This function calculates aerodynamic resistance to heat transport in neutral stability of atmosphere. Aerodynamic resistance determines the transfer of heat and water vapour from the evaporating surface into the air above the canopy.
        Output of this function is aerodynamic resistance(s/m-1)
        Input to this function is friction velocity
    '''
    return (np.log(2/0.1))/(Friction*0.41)


def AirDensity(AirPressure20, LST):
    '''
        This function calculates Air density for average 20 centigrade temperature
        Input is air pressure computed from function AirPressure20 (between 87 and 105 kPa)
        Output is air density in kilogram per cubic meter(Kg/m3) (between 1 to 1.5)
    '''
    #AirDensityy
    return (1000*AirPressure20)/(1.01*(LST)*287)

def AirPressure20Degrees(dem):
    '''
        Function for calculation of Atmospheric pressure in 20 centigrade temperature
        Input is digital elevation model (DEM).
        Output is Atmospheric pressure in kPa (Kilo paskal)

    '''
    #AirPressure20
    return 101.3*((293-0.0065*dem)/293)**5.26

def _albedo(albedotoa, transmiss):
    '''
    Function for calculation of Albedo from land surface. The albedo of a surface is the ratio of radiation reflected from the surface to the incident radiation
    Inputs are top of atmosphere albedo (0 to 1) and atmospheric transmissivity(0 to 1)
    Output is ground albedo (between 0 and 1, dimensionless)
    '''
    #Land Surface Albedo between 0 and 1
    albedo=(albedotoa-0.03)/(transmiss**2)
    albedo[albedo <0]= np.nan
    albedo[albedo > 1]= np.nan
    return albedo

def _albedo_top_atmosphere(w_band2, reflectance_band2, w_band3, reflectance_band3, w_band4, reflectance_band4, w_band5, reflectance_band5, w_band6, reflectance_band6, w_band7, reflectance_band7):
    '''
    albedo at the top of the atmosphere
    '''
    return ( w_band2 * reflectance_band2 ) +( w_band3 * reflectance_band3 ) + ( w_band4 * reflectance_band4 ) + ( w_band5 * reflectance_band5 ) + ( w_band6 * reflectance_band6 ) + ( w_band7 * reflectance_band7 )


def albedomask(albedo):
    '''
    creates a mask for albedo to choosing hot and cold pixel
    '''
    # TODO:
    # BUG:  albedo must be between -1 and 1
    Winsize=7
    core = np.full((Winsize, Winsize),1/Winsize**2)
    avefil=convolve2d(albedo, core, mode='same')
    stdv=generic_filter(albedo, functools.partial(np.std, ddof=1), size=Winsize)
    Albedo_mask = stdv/avefil
    # print(stdv[np.array([443, 443, 443, 443,454, 454, 454]), np.array([573, 575, 577, 579, 573, 575, 577])])
    # print(avefil[np.array([443, 443, 443, 443,454, 454, 454]), np.array([573, 575, 577, 579, 573, 575, 577])])
    Albedo_mask=np.where(Albedo_mask > 0.25, 0,1)
    return Albedo_mask

def _BT(meta_k2b, meta_k1b, Radiance_band):
    '''
    brightness temperature
    '''
    return meta_k2b / ( np.log( (meta_k1b/Radiance_band) +1 ) )

def classfilt(LandCover, Agri_code, R, R1, longs, lats, FileDir):
    '''
    create filter for LST with 7*7 neighborhood
    '''
    # TODO:  remove this:
    from .load_data import RasterBand
    band= RasterBand(FileDir)
    dataset= band.band2

    filtsize = 7
    Winsize = int((filtsize-1)/2)
    classmask1=np.zeros(shape=[R,R1])

    for i in range(Winsize, classmask1.shape[0]-Winsize):
        for j in range(Winsize, classmask1.shape[1]-Winsize):
            if (np.all(LandCover[i-Winsize: i+Winsize+1, j-Winsize:j+Winsize+1] ==Agri_code )):
                classmask1[i,j]=1

    #circle center on array
    r, c=dataset.index(longs, lats)

    #circle radius
    x, y=dataset.index(longs+50000, lats)
    radius=abs(c-y)+1

    #make circle mask
    arr_y, arr_x = np.ogrid[-r:R-r, -c:R1-c]
    circlePixels = arr_x*arr_x + arr_y*arr_y <= radius*radius

    classmask=circlePixels*classmask1

    return classmask

def _cavity(Es, Ev, Fprim, vegetationfraction):
    return ( 1 - Es ) * Ev * Fprim * ( 1 - vegetationfraction )

def py_BinWidth(x, bw):
    start = np.floor(x.min() / bw) * bw
    end = np.ceil(x.max() / bw) * bw + bw
    return np.arange(start, end, bw)

def hotselect3(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir):
    '''hot pixel selecting proccess'''
    finalmask = finalmaskk(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir)
    Lstfin = finalmask*LST
    Lstfin1 = Lstfin[Lstfin!=0]
    Ndvifin = finalmask*NDVI
    Ndvifin1=Ndvifin[Ndvifin!=0]

    #NL= the count in each bin for LST histogram,  %edgesL=bin edges for LST histogram
    binwidth=0.25
    (NL_h, edgesL_h, temp) = plt.hist(Lstfin1.flatten(), bins = py_BinWidth(Lstfin1, binwidth))

    #Nn=the count in each bin for NDVI histogram,   %edgesN= bin edges for NDVI histogram
    binwidth=0.01
    (Nn_h, edgesN_h, temp) = plt.hist(Ndvifin1.flatten(), bins = py_BinWidth(Ndvifin1, binwidth))

    areaLST_h=  np.sum(0.25*NL_h)
    areaNDVI_h= np.sum(0.01*Nn_h)

    # create the histogram
    for n1_h in range(1, 11):
        for n2_h in range(1, 11):

            #NDVI
            #Nna = The cumulative frequency of Nn
            _=0
            Nna_h= []
            for item in Nn_h:
                _+=item
                Nna_h.append(_)

            #Cndvi= Culomn of ndvi
            Nna_h=np.array(Nna_h)
            Cndvi_h= np.where( 0.01 * Nna_h <= (n2_h/100) * areaNDVI_h )

            #edge of Cndvi_h, acceptable NDVI value for selecting hot pixel
            accepNDVI_h = edgesN_h[Cndvi_h]

            #acceptable NDVI range for selecting hot pixel
            NDVIrange_h=np.logical_and(Ndvifin > 0, Ndvifin < np.max(accepNDVI_h))

            #LST
            #NLa = The cumulative frequency of NL
            #n[::-1]: reverse array
            _=0
            NLa_h= []
            for item in NL_h[::-1]:
                _+=item
                NLa_h.append(_)

            #Clst = culomn of lst
            NLa_h= np.array(NLa_h)
            Clst_h= np.where( 0.25 * NLa_h <= (n1_h/100) * areaLST_h )

            #acceptable LST value for selecting hot pixel
            accepLST_h= edgesL_h[Clst_h]

            #acceptable LST range for selecting hot pixel
            LSTrange_h= Lstfin > np.min(accepLST_h)

            hotRange = LSTrange_h * NDVIrange_h
            Nhot= np.sum(hotRange==1)

            if Nhot>=10:
                hot_select=LST [ hotRange==1 ]
                Hot_map = LST * hotRange
                return hot_select

    raise Exception("error:\n I happen in rare conditions :-@ ")

def coldselect3(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir):
    '''hot pixel selecting proccess'''
    finalmask = finalmaskk(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir)
    Lstfin = finalmask*LST
    Lstfin1 = Lstfin[Lstfin!=0]
    Ndvifin = finalmask*NDVI
    Ndvifin1=Ndvifin[Ndvifin!=0]

    #NL= the count in each bin for LST histogram,  %edgesL=bin edges for LST histogram
    binwidth=0.25
    (NL_c, edgesL_c, temp) = plt.hist(Lstfin1.flatten(), bins = py_BinWidth(Lstfin1, binwidth))
    #Nn=the count in each bin for NDVI histogram,   %edgesN= bin edges for NDVI histogram
    binwidth=0.01
    (Nn_c, edgesN_c, temp) = plt.hist(Ndvifin1.flatten(), bins = py_BinWidth(Ndvifin1, binwidth))

    areaLST_c=  np.sum(0.25*NL_c)
    areaNDVI_c= np.sum(0.01*Nn_c)

    # create the histogram
    for n1_c in range(1, 11):
        for n2_c in range(1, 11):

            #NDVI
            #Nna = The cumulative frequency of Nn
            _=0
            NLa_c= []
            for item in NL_c:
                _+=item
                NLa_c.append(_)

            #Cndvi= Culomn of ndvi
            NLa_c=np.array(NLa_c)
            Clst_c= np.where(0.25 * NLa_c <= (n1_c/100) * areaLST_c)


            #edge of Cndvi_h, acceptable NDVI value for selecting hot pixel
            accepLST_c = edgesL_c[Clst_c]

            #acceptable NDVI range for selecting hot pixel
            LSTrange_c=np.logical_and(Lstfin > 0, Lstfin < np.max(accepLST_c))

            #LST
            #NLa = The cumulative frequency of NL
            #n[::-1]: reverse array
            _=0
            Nna_c= []
            for item in Nn_c[::-1]:
                _+=item
                Nna_c.append(_)

            #Clst = culomn of lst
            Nna_c= np.array(Nna_c)
            Cndvi_c= np.where( 0.01 * Nna_c <= (n2_c/100) * areaNDVI_c )

            #acceptable LST value for selecting hot pixel
            accepNDVI_c= edgesN_c[Cndvi_c]

            #acceptable LST range for selecting hot pixel
            NDVIrange_c= Ndvifin > np.min(accepNDVI_c)

            ColdRange = LSTrange_c * NDVIrange_c
            Ncold= np.sum(ColdRange==1)

            if Ncold>=10:
                cold_select=LST [ ColdRange==1 ]
                cold_map = LST * ColdRange
                return cold_select

    raise Exception("error:\n I happen in rare conditions :-@ ")


def _HT200(L, PSI200, pi):
    ht200=np.zeros_like(PSI200) * np.nan
    ht200[L < 0] = (2*np.log((1+PSI200)/2)+np.log((1+PSI200**2)/2)-2*np.arctan(PSI200)+0.5*pi)[L < 0]
    ht200[L > 0]= (-5 * (2/L))[L > 0]
    return ht200

def _HT2(L, PSI2):
    ht2=np.zeros_like(PSI2) * np.nan
    ht2[L > 0] =  (-5*(2/L))[L > 0]
    ht2[L < 0] =(2*np.log((1+PSI2**2)/2))[L < 0]
    return ht2

def dThott(AirDensity, Rah, H_hot, LST, LST_hotpixel):
    '''
    dThott2 removed
    '''
    dThot=np.zeros_like(LST)
    dThot[np.logical_and(LST > (LST_hotpixel-0.5), LST < (LST_hotpixel+0.5))]=(H_hot*Rah/(AirDensity*1004))[np.logical_and(LST > (LST_hotpixel-0.5), LST < (LST_hotpixel+0.5))]
    return np.mean(dThot[dThot>0])

def FrictionStation(param, Zwin, Zveg):
    '''
    This function claculates friction velocity (Friction velocity quantifies the turbulent velocity fluctuations in the air)
    Inputs: param (struct),Wind measurement elevation(double),Vegetation elevation(double)
    Ouputs: Friction velocity (m/s)
    '''
    return 0.41 * param / ( np.log( Zwin / ( 0.12* Zveg ) ) )

def FrictionVelocity (wind200, Zom):
    '''
    Function for friction velocity calculation. (Friction velocity quantifies the turbulent velocity fluctuations in the air)
    Input is Zom and friction velocity at.
    Output is Friction velocity (m/s)
    '''
    #Friction
    return (0.41*wind200)/(np.log(200/Zom))

def _Friction(L, wind200, Zom, HT200):
    friction=np.zeros_like(wind200) * np.nan
    friction[L < 0]= ( (0.41*wind200) / ( np.log(200/Zom) - HT200 ) )[L < 0]
    friction[L > 0]= ((0.41 * wind200 ) / ( np.log( 200 / Zom ) - HT200 ))[L > 0]
    friction[ L==0 ]= (( 0.41*wind200 ) / (np.log( 200/ Zom)))[ L==0 ]
    friction[np.isnan(L)]=np.nan
    return friction

def LongWaveIncome(transmiss, tscold):
    #LongWave Income Radiation
    return 0.85*((-np.log(transmiss))**0.09)*(5.67*10**-8)*(tscold**4)

def LongWaveOut(emissivity, LST):
    '''Longwave Outward Radiation in watt/m2'''
    return emissivity*(5.67*10**(-8))*LST**4

def GroundFlux (LST, Albedo, NDVI, RN):
    '''
    Function for Ground Heat Flux calculation.
    Inputs are land surface temperature (LST), Albedo, NDVI and Rn (Net radiation)
    Output is Ground Heat in watt/m2
    '''
    #GroundHeat
    return (((LST-273.15)/Albedo)*((0.0038*Albedo + 0.0074*Albedo**2)*(1-0.98*NDVI**4)))*RN

def Ghotpixel(G, LST_hot):
    return np.mean(G[LST_hot > 0])

def Hhotpixel(H, LST_hot):
    return np.mean(H[LST_hot > 0])

def _HT_1(PSI1, L):
    HT1=np.zeros_like(PSI1) * np.nan
    HT1[L < 0]=(2*np.log((1+PSI1**2)/2))[L < 0]
    HT1[L > 0]=(-5*(0.1/L))[L > 0]
    return HT1

def LeafAreaIndex(NDVI):
    '''
    Function for Leaf Area Index calculation from normalized SAVI vegetation index. LAI is one sided area of leaves in one square meter of ground (m2/m2, dimensionless).
    Input is SAVI index
    Output is LAI for each pixel of image.
    '''
    # BUG: bug .69-.69 = 0 -> log(0) -> -inf
    # change SAVIn >= 0.69 and convert to .689
    # SAVIn[np.where(SAVIn>=0.69)]=0.689
    # Leaf Area Index (Dimensionless) ranges in 0 to 6
    return 5 * ( (NDVI - 0.01) / (np.max(NDVI)-0.01) )

def MomentumRoughnessLength(NDVI, albedo, LAI):
    '''
    calculate momentum roughness length
    '''
    a1=0.26
    b1=-2.21
    zom=0.018*LAI
    zom[LAI <= 0]=  0.001
    zom[NDVI < 0]=  0.001
    zom[np.logical_not(NDVI >= 0)]=np.exp( ( a1 *NDVI / albedo ) + b1 )[np.logical_not(NDVI >= 0)]
    return zom

def MoninObukhovLength(airdensity, LST, friction, H):
    '''
    MoninObukhovLength: airdensity, LST, friction, H
    '''
    #L
    return np.array(-(1004*airdensity*LST*(friction**3))/((9.81*0.41)*H))

def instantET(LET, vapor_latent):
    ETinst= 3600*(LET/vapor_latent)
    ETinst[ETinst<0]=0
    return ETinst

def SensibleHeatFlux (airdensity, dt, rah):
    '''
    This function calculates Sensible heat flux. Sensible heat flux is the rate of heat loss to the air by convection and conduction, due to a temperature difference
    Inputs to H function are airdensity in kg/m3, temperature difference between 0.1 m and 2m above surface and Aerodynamic resistance.
    Output is Sensible Heat Flux in watt/m2.
    '''
    #Calculation of Sensible Heat Flux
    #H
    return (airdensity*1004*dt)/rah

def ShortWaveIncome(zenith,transmiss, dr):
    '''
    This function calculates short wave radiation reaching earth surface in watt/m2.
    Inputs are zenith angle, atmospheric transmissivity and earth sun distance.
    Output is Short wave radiation that reach the earth.

    Gsc = 1367; % solar constant in watt/m2
    Shortwave income radiation to earth surface
    Shortwave
    '''
    return 1367*np.cos(zenith)*transmiss*dr

def ShortWaveIncome_metric(transmiss, dr):
    '''
    This function calculates short wave radiation reaching earth surface in watt/m2.
    Inputs are zenith angle, atmospheric transmissivity and earth sun distance.
    Output is Short wave radiation that reach the earth.

    Gsc = 1367; % solar constant in watt/m2
    Shortwave income radiation to earth surface
    Shortwave
    '''
    return 1367*transmiss*dr


def SoilAdjustedVegetationIndex(Band5, Band4):
    '''
    Function for soil adjusted vegetation index calculation from
    near infrared and red bands of satellite image. SAVI is used in Sebal
    model for LAI estimation
    Inputs are Ner Infrared and Red bands
    Output is SAVI (between -1 and 1)
    '''
    #Soil Adjusted Vegetation Index between -1 and 1;
    #SAVI
    if (Band5+Band4+0.5).all() == 0:
        return 0

    temp=(1+0.5)*((Band5-Band4)/(0.5+Band5+Band4))
    temp[temp <= 0]=10e-10
    return temp


def sumfilt(classmask, LST_mask, NDVI_mask, Albedo_mask, Fmaskk):
    """
    sum of filters (classfilt, lstmask, albedomask, fmask1, NDVImask)
    """
    # print(classmask[3,53], LST_mask[3,53], NDVI_mask[3,53], Albedo_mask[3,53], Fmaskk[3,53])
    Sum_filt=np.zeros_like(classmask)
    Sum_filt[(classmask + LST_mask + NDVI_mask + Albedo_mask + Fmaskk )==5]=1
    # Sum_filt[np.isnan(LST_mask)]=np.nan
    return Sum_filt

def StdFilter(Classified_image):
    #filter size
    filtsize = 7
    Winsize = (filtsize-1)/2

    #number of rows and columns
    row, col = Classified_image.shape
    Std_image=np.zeros_like(Classified_image)

    for i in range(Winsize, Classified_image.shape[0]-Winsize):
        for j in range(Winsize, Classified_image.shape[1]-Winsize):
            Window = Classified_image[i-Winsize: i+Winsize+1, j-Winsize:j+Winsize+1]
            Std_image[i,j]= np.nanstd(Window, ddof=1)

    return Std_image

def slopea(dThot, dTcold, LST_hotpixel, LST_coldpixel):
    return (dThot-dTcold)/(LST_hotpixel-LST_coldpixel)

def Transmissivity (DEM):
    '''
    Function for Atmospheric Transmissivity calculation from DEM. Atmospheric Transmissivity is rate of transfer of energy from atmosphere to earth.
    Input is DEM.
    Output is Atmospheric Transmissivity (between 0 and 1)
    '''
    #atmospheric Transmissivity between 0 and 1
    #transmiss
    return 0.75+2*(10**-5)*DEM

def WindSpeed200(FrictionStation, Zom):
    '''
    Function for wind speed at 200m calculation.
    Input is Zom and friction velocity of station.
    Output is wind speed at 200m above ground surface (m/s).
    '''
    return FrictionStation*((np.log(200/Zom))/0.41)

def ndvii(Band5, Band4):
    '''
    Function for normalized difference vegetation index calculation from
    near infrared and red bands of satellite image.
    Inputs are Ner Infrared and Red bands
    Output is NDVI (between -1 and 1)
    '''
    # TODO:
    # BUG:  Band5+Band4 == 0:
    #NormalizedIndex
    # if Band5+Band4 == 0:
    #     return 0
    return (Band5 - Band4)/(Band5 + Band4)

def _NDWI(Reflectance_band_a, Reflectance_band_b):
    '''
    NDWI calculation
    '''
    return ( Reflectance_band_a -  Reflectance_band_b ) / ( Reflectance_band_a + Reflectance_band_b )

def Emissivity(ndvi):
    '''
    Function for calculation of Emissivity using NDVI.
    Emissivity is the potential of a surface or material for emitting or radiating energy.
    Input to this function is NDVI(normalized difference vegetation index).
    Output to this function is emissivity of ground surface.
    Emissivity in ranges between 0 and 1
    '''
    emissivity = 1.009+0.047*np.log(ndvi)

    #z[np.where(np.isnan(z))]=0
    # BUG: const=1.009+0.047*np.log(10e-10)
    #      emissivity[np.where(np.isnan(emissivity))]=const
    #      emissivity[np.where(np.isinf(emissivity))]=const
    return emissivity

def emissivity1(NDVI):
    Emissiv_1=np.zeros_like(NDVI) * np.nan
    Emissiv_1[NDVI < 0]=1
    Emissiv_1[np.logical_and(NDVI >=0, NDVI< 0.125)]= 0.92
    Emissiv_1[NDVI >= 0.125]=np.real(Emissivity(NDVI[NDVI >= 0.125]))
    return Emissiv_1

def emissivity10(NDVI, Ev10, Es10, vegetationfraction, Cavity10, band4):
    Emissiv_10=np.zeros_like(NDVI) * np.nan
    Emissiv_10[np.logical_and(NDVI >= 0.2, NDVI <= 0.5)]=(Ev10*vegetationfraction)+ Es10*(1-vegetationfraction)+Cavity10
    Emissiv_10[NDVI < 0.2] = 0.973- 0.047*band4
    Emissiv_10[NDVI > 0.5] = Ev10 + Cavity10
    return Emissiv_10

def emissivity210(NDVI):
    NDmin=np.min(NDVI[NDVI>0])
    NDmax=np.max(NDVI)
    Pv=(NDVI-NDmin)/(NDmax-NDmin)
    Emissiv_210=np.zeros_like(NDVI) * np.nan

    if NDmax-NDmin == 0:
        Pv=0

    Emissiv_210[NDVI<0]= 0.991
    Emissiv_210[np.logical_and( NDVI>=0, NDVI<0.2 )]=0.964
    Emissiv_210[NDVI >= 0.5]=0.984
    _=np.logical_and(NDVI >= 0.2, NDVI < 0.5)
    Emissiv_210[_]=0.984*Pv[_]+0.964*(1-Pv[_])+(1-0.964)*(1-Pv[_])*0.55*0.984

    return Emissiv_210

def emissivity211(NDVI):
    NDmin=np.min(NDVI[NDVI>0])
    NDmax=np.max(NDVI)
    Pv=(NDVI-NDmin)/(NDmax-NDmin)
    Emissiv_211=np.zeros_like(NDVI) * np.nan

    if NDmax-NDmin == 0:
        Pv=0

    Emissiv_211[NDVI<0]= 0.986
    Emissiv_211[
    np.logical_and(np.isnan(Emissiv_211),
                  np.logical_and( NDVI>=0, NDVI<0.2 )
                  )
    ]=0.970

    Emissiv_211[
                np.logical_and(np.isnan(Emissiv_211),NDVI >= 0.5)
    ]=0.980

    _=np.logical_and(np.isnan(Emissiv_211),
                    np.logical_and(NDVI >= 0.2, NDVI < 0.5)
                    )
    Emissiv_211[_]=0.980*Pv[_]+0.970*(1-Pv[_])+(1-0.970)*(1-Pv[_])*0.55*0.980

    return Emissiv_211

def _emissivity3_10(NDVI, vegetationfraction, Es10, Cavity10, Reflectance_band4, Ev10):
    emissivity10=np.zeros_like(NDVI) * np.nan
    _=np.logical_and(NDVI >= 0.2, NDVI <= 0.5)
    emissivity10[_]= ( Ev10 * vegetationfraction[_] ) + Es10 * ( 1 - vegetationfraction[_] ) + Cavity10[_]
    _=np.logical_and(NDVI < 0.2, NDVI >= 0)
    emissivity10[_]= 0.973 - 0.047 * Reflectance_band4[_]
    _=NDVI > 0.5
    emissivity10[_]= Ev10 + Cavity10[_]
    emissivity10[ NDVI < 0 ]= 1
    emissivity10[ np.isnan(NDVI) ]= np.nan
    return emissivity10

def _emissivity3_11(NDVI, vegetationfraction, Es11, Cavity11, Reflectance_band4, Ev11):
    emissivity11=np.zeros_like(NDVI) * np.nan
    _=np.logical_and(NDVI >= 0.2, NDVI <= 0.5)
    emissivity11[_]= ( Ev11 * vegetationfraction[_] ) + Es11 * ( 1 - vegetationfraction[_] ) + Cavity11[_]
    _=np.logical_and(NDVI < 0.2, NDVI >= 0)
    emissivity11[_]= 0.984 - 0.026 * Reflectance_band4[_]
    _= NDVI > 0.5
    emissivity11[_]= Ev11 + Cavity11[_]
    emissivity11[ NDVI < 0 ]= 1
    emissivity11[ np.isnan(NDVI) ]= np.nan
    return emissivity11

def EvaporativeFriction(Rn, H, G):
    '''
    This function calculates Evaporative Friction
        Inputs: Rn (2D double), H (2D double), G (2D double), R (map.rasterref.MapCellsReference)
        Ouputs: Emissivity (2D double)
    '''
    evapo_fric=np.zeros_like(Rn)
    ss= Rn-G
    qq= (Rn-H-G)/(Rn-G)
    evapo_fric[ss != 0] =qq[ss != 0]
    evapo_fric[ evapo_fric<0 ] = 0
    evapo_fric[evapo_fric>1] = 1
    return evapo_fric

def Evapot24(evapo_fric, Rn24, vapor_latent):
    ET24 = (86400*evapo_fric*Rn24)/vapor_latent
    ET24[ET24<0]=0
    return ET24

def ffmask(fmask, R, R1):
    filtsize=7
    Winsize = int((filtsize-1)/2)
    Fmaskk=np.zeros_like(fmask)

    for i in range(Winsize, Fmaskk.shape[0]-Winsize):
        for j in range(Winsize, Fmaskk.shape[1]-Winsize):
            Window2=fmask[i-Winsize: i+Winsize+1, j-Winsize:j+Winsize+1]
            if not (np.any(Window2==2) or np.any(Window2==4)):
                Fmaskk[i,j]=1

    return Fmaskk

def finalmaskk(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir):
    #create filter for LST with 7*7 neighborhood
    lats=param.Latitude
    longs=param.longitude

    classmask = classfilt(LandCover, Agri_code, R, R1, longs, lats, FileDir)
    #creates a mask for LST to choosing hot and cold pixel
    LST_mask = lstmask(LST)
    #creates a mask for NDVI to choosing hot and cold pixel
    NDVI_mask = ndvimask(NDVI)
    #creates a mask for albedo to choosing hot and cold pixel
    Albedo_mask = albedomask(albedo)
    #this function removes pixels within clouds or cloud shadows
    Fmaskk = ffmask(fmask,R,R1)

    #Sum_filt=sumfilt(classmask, LST_mask, NDVI_mask, Albedo_mask, Fmaskk)
    Sum_filt = classmask + LST_mask + NDVI_mask  + Albedo_mask + Fmaskk
    #removes objects containing fewer than 50 pixels
    morph50 = morphomask50(Sum_filt)

    return morph50

def Conversion_from_Radiance_to_Reflectance(multirefb , Band, addrefb, Elevation):
    '''
    Conversion from Radiance to Reflectance (USGS user handbook,2016)
    '''
    return ( multirefb * Band + addrefb ) / ( np.sin(Elevation) )

def Calculation_of_Brightness_Temperature_for_bands(Meta_k2b, Meta_k1b, Radiance_band):
    return  Meta_k2b/np.log((Meta_k1b/Radiance_band)+1)

def albedo_at_the_top_of_the_atmosphere(w_band2, Reflectance_band2, w_band3, Reflectance_band3, w_band4, Reflectance_band4, w_band5, Reflectance_band5, w_band6, Reflectance_band6, w_band7, Reflectance_band7):
    return (w_band2*Reflectance_band2)+(w_band3*Reflectance_band3)+(w_band4*Reflectance_band4)+(w_band5*Reflectance_band5)+(w_band6*Reflectance_band6)+(w_band7*Reflectance_band7)

def Conversion_pixel_DN_values_to_radiance(Meta_addradb, Meta_multiradb, Band):
    return Meta_addradb + (Meta_multiradb*Band)

def FVC(NormalizedVegetationIndex, maxNDVI):
    #fvc
    return (NormalizedVegetationIndex - 0.05)/(maxNDVI - 0.05)

def lse_11(fvc):
    #Land Surface Emissivity band 11
    return  0.977*(1-fvc)+0.989*fvc

def r_sky(param_t):
    return (0.0000000001807)*((param_t+273.15)**4)*(1-0.26*np.exp(-0.000777*(param_t)**2))

def R_C(Radiance_band, lse, rsky):
    return Radiance_band - (1-lse)*rsky

def _Rah(L, HT2, HT1, Friction):
    rah=np.zeros_like(Friction) * np.nan
    rah[L <0]=(np.real((np.log(2/0.1)- HT2 + HT1) / (Friction*0.41) ))[L <0]
    rah[L > 0]=( np.real( ( np.log( 2/0.1 )- HT2 + HT1 ) / (Friction*0.41) ))[L > 0]
    rah[ L==0 ]= (np.real(( np.log(2/0.1) / ( Friction * 0.41 )))[ L==0 ])
    rah[np.isnan(L)]=np.nan
    return rah

def Normalized_SAVI(SAVI):
    #SAVIn
    savimin=np.min(SAVI)
    savimax=np.max(SAVI)
    return ((SAVI - savimin)*(0.69))/(savimax - savimin)

def ndvimask(NDVI):
    '''
    creates a mask for NDVI to choosing hot and cold pixel
    '''
    #creates average filter
    Winsize=7
    core = np.full((Winsize, Winsize),1/Winsize**2)
    avefil1=convolve2d(NDVI, core, mode='same')

    #creates std filter
    stdv=generic_filter(NDVI, functools.partial(np.std, ddof=1), size=Winsize)

    #creates CV filter
    NDVI_mask = stdv/avefil1

    NDVI_mask=np.where(NDVI_mask > 0.25, 0, 1)

    return NDVI_mask

def netrad24(param, Meta, albedo, InstAtmTransmiss, AtmTransmiss24):
    DOY=Meta.julianday

    #inverse distance between Earth - Sun
    dr = 1 + 0.033*np.cos(((2*pi)/365)*Meta.julianday)

    #solar declination
    Solar_Dec = 0.409*np.sin((2*pi*DOY/365)-1.39)

    #Sunset_hr_angle(Rad)
    Sunset_hr_angle = np.arccos(-tan(param.LatDeg*pi/180)*tan(Solar_Dec))

    InstIncomRl = (0.85*(-log(InstAtmTransmiss))**(0.09))*(5.67*10**(-8))*(param.Tinst**4)

    Ra24Flat = 435.2*dr*(Sunset_hr_angle*np.sin(param.LatDeg*pi/180)*np.sin(Solar_Dec)+np.cos(param.LatDeg*pi/180)*np.cos(Solar_Dec)*np.sin(Sunset_hr_angle))

    SatVaporPress = 0.6108*(exp((17.27*param.Tmean)/(param.Tmean+237.3)))

    #Slope of saturate vapor pressure(KPa/k)
    SlopeSatvap = (4098*SatVaporPress)/(param.Tmean+237.3)**2

    #Actual Vapor Pressure (KPa)
    ActVaporPress = param.RH * SatVaporPress

    #w/m2
    Rnl24 = (5.67*10**-8)*(param.Tmean+273.15)**4*(0.34-0.14*(ActVaporPress**(0.5)))*(1.35*(AtmTransmiss24/0.8)-0.35)

    #w/m2
    Rn24 = Ra24Flat*AtmTransmiss24*(1-albedo)-Rnl24
    return Rn24

def netrad24_metric(param, Meta, albedo, CosZn, InstAtmTransmiss, AtmTransmiss24):
    '''
    This function calulates 24 hours net radiation from METRIC method
    Inputs: albedo (2d double), param (struct), Meta (struct), CosZn (2D double)
    Ouputs: Rn24 (2d double)
    '''
    DOY=Meta.julianday

    #solar declination
    Solar_Dec = 0.409*np.sin((2*pi*DOY/365)-1.39)

    #Sunset_hr_angle(Rad)
    Sunset_hr_angle = np.arccos(-tan(param.LatDeg*pi/180)*tan(Solar_Dec))

    InstIncomRl = (0.85*(-log(InstAtmTransmiss))**(0.09))*(5.67*10**(-8))*(param.Tinst**4)

    Ra24Flat = 435.2*Meta.dr*(Sunset_hr_angle*np.sin(param.LatDeg*pi/180)*np.sin(Solar_Dec)+np.cos(param.LatDeg*pi/180)*np.cos(Solar_Dec)*np.sin(Sunset_hr_angle))

    SatVaporPress = 0.6108*(exp((17.27*param.Tmean)/(param.Tmean+237.3)))

    #Slope of saturate vapor pressure(KPa/k)
    SlopeSatvap = (4098*SatVaporPress)/(param.Tmean+237.3)**2

    #Actual Vapor Pressure (KPa)
    ActVaporPress = param.RH * SatVaporPress

    #w/m2
    Rnl24 = (5.67*10**-8)*(param.Tmean+273.15)**4*(0.34-0.14*(ActVaporPress**(0.5)))*(1.35*(AtmTransmiss24/0.8)-0.35)

    #w/m2
    Rn24 = CosZn*Ra24Flat*AtmTransmiss24*(1-albedo)-Rnl24
    return Rn24

def NetRadiation(albedo, kin, Lin, Lout, Emiss):
    return ((1-albedo)*kin+Lin - Lout-(1-Emiss)*Lin).astype(float)

def Friction_Velocity_at_station(param_WindSpeed):
    #Friction_station
    return 0.41*param_WindSpeed/(log(2/0.12*0.2))

def Sensible_Heat_Flux_of_Cold_Pixel(RNcold, Gcold, Ref_ET):
    #Hcold
    return RNcold - Gcold - 1.05*((2450000/86400)*(Ref_ET))

def Air_Density_kg_m3(DEM):
    #Air_Density kg to m3
    return (1000*(101.3*((293-0.0065*DEM)/293)**5.26))/(1.01*(20+273)*287)

def Reference_Evapo(param, Meta):
    '''
    This function calculates Crop Reference Evapotranspiration (ET0) from meteorological data based on FAO56 manual (FAO Penman-Monteith method)
    Reference crop is a full grown crop like alfalfa or grass in large fields in good standard condition without no stress and with an assumed 0.12 meter height.
    Inputs for ET0 calculation are wind speed (daily mean, m/s, meter per second, 2 meter above ground), air temperature (minimum, maximum and mean of day in centigrade) and relative humidity (daily mean). Latitude (decimal degrees), elevation (meters above sea level) and julian day should also be known.
    output is ET0 in millimeter per day, mm/day.

    param.Tmean = (param.Tmin+param.Tmax)/2;
    moved to Param class
    '''

    #Slope of Saturation Vapour Pressure Curve in kPa/C (kilo Paskal divided to Degrees Centigrade)
    SOS = (4098 * (0.6108 * np.exp(17.27*param.Tmean)/(param.Tmean + 237.3))) / ((param.Tmean + 237.3)**2)

    #Air Pressure in kPa (kilo Paskal)   Between 87 and 105 kPa
    AirPressure = 101.3 * ((293-0.0065 * param.Elevation) / 293) ** 5.26

    #Psychrometric Constant in kPa/C (kilo Paskal divided to Degrees Centigrade)
    PsychrometricConstant = 0.000665 * AirPressure

    #Minimum Saturation Vapour Pressure in kPa (kilo Paskal)
    esmin = 0.6108 * np.exp ((17.27 * param.Tmin)/(param.Tmin + 237.3))

    #Maximum Saturation Vapour Pressure in kPa (kilo Paskal)
    esmax = 0.6108 * np.exp ((17.27 * param.Tmax)/(param.Tmax + 237.3))

    #Mean Saturation Vapor Pressure in kPa (kilo Paskal)
    es = (esmin + esmax)/2

    #DewPoint Temperature Calculation
    tdew = (112+0.9*param.t)*param.RH**0.125+(0.1*param.t-112)

    #Actual vapour pressure in kPa (kilo Paskal)
    ea = 0.6108 * np.exp ((17.27 * tdew)/(tdew + 237.3))

    # Vapor Pressure Deficit  in kPa (kilo Paskal)
    VapourPressureDeficit = es - ea

    #Solar Declination
    SolarDeclination = 0.409*np.sin((2*pi/365)*Meta.julianday - 1.39)

    #Latitude in radians
    Latitude = (pi/180)*param.Latitude

    #Sunset Hour Angle
    ws = np.arccos(- np.tan(Latitude)*np.tan(SolarDeclination))

    #inverse distance between Earth - Sun
    dr = 1 + 0.033*np.cos(((2*pi)/365)*Meta.julianday)

    #solar constant in MJ/m/min (Megajoul to square meter to minute)
    Gsc = 0.0820

    #Extraterresterial Radiation for Daily Periods in MJ/m/day (Megajoul to square meter to day)
    Ra = (1440/pi) * Gsc*dr *(ws*np.sin(Latitude)*np.sin(SolarDeclination)+np.cos(Latitude)*np.cos(SolarDeclination)*np.sin(ws))

    #Sunshine Hours, maximum hours that sun can illuminate earth in the day.
    SunHour = (24/pi) * ws

    #Solar radiation in MJ/m/day (Megajoul to square meter to day)
    Rs = (0.25+(0.5*param.ActualSunshine/SunHour))*Ra

    #clear-sky solar radiation [MJ m-2 day-1] (Megajoul to square meter to day)
    Rso = (0.75+ 0.00002* param.Elevation) * Ra

    #Albedo of hypothetical grass reference crop (dimensionless)
    Alfa = 0.23

    #Net shortwave radiation in MJ/m/day (Megajoul to square meter to day)
    Rns = (1-Alfa)*Rs

    #Stefan-Boltzmann constant (MJ K-4 m-2 day-1)
    Ro = 4.903*10**-9

    #net outgoing longwave radiation [MJ m-2 day-1]
    Rnl = Ro* (((param.Tmax+273.16)**4+(param.Tmin+273.16)**4)/2)*(0.34-0.14*np.sqrt(ea))*(1.35*(Rs/Rso-0.35))

    #Net Radiation [MJ m-2 day-1]
    Rn = Rns -Rnl

    #Reference Evapotranspiration in mm/day (millimeter per day)
    Ref_ET = (0.408*SOS*(Rn)+PsychrometricConstant*(900/(param.Tmean+273))*param.WindSpeed*VapourPressureDeficit)/(SOS+PsychrometricConstant*(1+0.34*param.WindSpeed))

    return Ref_ET

def morphomask50(Sum_filt):
    #removes objects containing fewer than 50 pixels
    i,j=np.where(np.isnan(Sum_filt))
    Sum_filt[i,j]=0

    Sum_filt= morphology.remove_small_objects(Sum_filt.astype(bool), min_size=50, connectivity=8)

    return Sum_filt.astype(int)


def max_NDVI(one_d_array):
    return np.max(one_d_array)

def lst1(Meta,lse11,Rc):
    '''
    LST function calculates land surface temperature from thermal infrared
    bands of landsat8 satellite image.
    Inputs to this function are the K1 and K2 coefficients, land surface
    emissivity and thermal radiance from the surface(Rc)
    '''
    return Meta.k2b11/(np.log(((lse11*Meta.k1b11)/Rc)+1))

def lst10(emissivity, radiance, meta1, meta2):
    '''
    LST function calculates land surface temperature from thermal infrared
    bands of landsat8 satellite image.
    Inputs to this function are the K1 and K2 coefficients, land surface
    emissivity and thermal radiance from the surface(Rc)
    '''
    return meta2/(np.log((meta1/radiance)+1)* emissivity ** 0.25)

def lst11(emissivity, radiance, meta1, meta2):
    return meta2/(np.log((meta1/radiance)+1)* emissivity ** 0.25)

def lst102(BT10, emissivity10):
    return  BT10/(1+((10.895*10**(-6))*BT10/0.01438)*np.log(emissivity10))

def lst112(BT11, emissivity11):
    return BT11/(1+((12.005*10**(-6))*BT11/0.01438)*np.log(emissivity11))

def lstcoldesa(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir):
    '''
    LST of cold pixel in ESA method
    '''
    cold_select = coldselect3(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir)
    return np.mean(cold_select)

def lsthotesa(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir):
    '''
    LST of cold pixel in ESA method
    '''
    hot_select = hotselect3(LST, LandCover, albedo, NDVI, fmask, R, R1, Agri_code, param, FileDir)
    return np.mean(hot_select)

def lstmask(LST):
    '''
    creates a mask for LST to choosing hot and cold pixel
    '''
    Winsize=7
    LST_mask=generic_filter(LST, functools.partial(np.std, ddof=1), size=Winsize)

    LST_mask[LST_mask > 1.5]=0
    LST_mask[LST_mask<=1.5]=1

    #LST_mask[np.logical_and(np.logical_or(LST > 335, LST < 273),
                            #np.logical_not(LST_mask > 1.5))]=0

    LST_mask[np.isnan(LST)]= np.nan

    #LST_mask[np.logical_and(LST_mask!=0, np.logical_not(np.isnan(LST)))]=1

    return LST_mask

def LST(NDVI, param, bt10, bt11):
    #NDVI1 = NDVI(:)
    #x(:) transforms the array to a column vector.
    NDVI1=NDVI.flatten()

    #maximum of NDVI
    maxNDVI=np.max(NDVI1)

    #minimum of NDVI
    minNDVI=np.min(NDVI1)

    #Fractional Vegetation Cover
    fvc = (NDVI - 0.05)/(maxNDVI - 0.05)

    #Land Surface Emissivity band 10
    lse10 = 0.971*(1-fvc)+0.987*fvc

    #Land Surface Emissivity band 11
    lse11 = 0.977*(1-fvc)+0.989*fvc

    #Difference of Land Surface Emissivity
    difflse= lse10-lse11

    #Mean of Land Surface Emissivity
    meanlse = (lse10+lse11)/2

    #calculation of dewpoint temperature
    tdew = (112+0.9*param.Tmean)*param.RH**0.125+(0.1*param.Tmean-112)

    #Vapor pressure
    ea = 0.6108*np.exp((17.27*tdew)/(tdew+237))

    #Water vapor in atmosphere
    W = ea*(10/9.81)

    #Constants of LST formula
    C=np.array([-0.268, 1.378, 0.183, 54.3, 2.238, -129.2, 16.4])

    #Formula for land surface temperature calculation
    LandSurfaceTemperature = bt10+C[1]*(bt10-bt11)+C[2]*(bt10-bt11)**2+C[0]+(C[3]+C[1]*W)*(1-meanlse)+(C[5]+C[6]*W)*difflse

    return LandSurfaceTemperature

def savi_min(SAVI):
    SAVI=SAVI.flatten()
    savimin=np.min(SAVI)
    return savimin

def savi_max(SAVI):
    SAVI=SAVI.flatten()
    savimax=np.max(SAVI)
    return savimax

def dT_cold(Hcold, rahcold, aircold):
    return (Hcold * rahcold)/(aircold*1004)

def dT_hotold(Hhot, rahhot, airhot):
    return (Hhot * rahhot)/(airhot*1004)

def air_density(Ta, DEM):
    return  349.467*(((Ta+0.0065*DEM)/Ta)**5.26)/Ta

def d_T(slope, LST, offset):
    return (slope*LST) + offset

def PSI_200(L):
    return np.real(np.power((1-16*(200/L)),0.25))

def PSI_2(L):
    return np.real(np.power((1-16*(2/L)), 0.25))

def PSI_1(L):
     return np.real((1-16*(0.1/L))**0.25)

def dT_hot_current(Hhot, rahhot, airhot):
    return (Hhot * rahhot)/(airhot*1004)

def regression(X, y):
    '''
    scikit-learn.LinearRegression().
    reg.coef_, reg.intercept_
    '''
    from sklearn import datasets, linear_model
    reg=linear_model.LinearRegression()
    reg.fit(X, y)
    return reg.coef_, reg.intercept_

def ltln2val(array ,dataset, lats, longs):
    '''
    return the array value of lat,long
    '''
    r,c=dataset.index(longs, lats)
    return array[r,c]

def ET_inst(LET):
    return 3600*(LET/(2.45*1000000))

def ET_rf(ETinst, Ref_ET):
    return ETinst/((Ref_ET)/24)

def ET_24(ETrf, Ref_ET):
    return ETrf*Ref_ET

def _LET(Rn, GroundHeat, H):
    return Rn - GroundHeat -H

def offsett(slope, dThot, LST_hotpixel):
    return dThot - (slope * LST_hotpixel)

def _vegetation_fraction(NDVI, NDVImin, NDVImax):
    return ( ( NDVI - NDVImin ) / ( NDVImax - NDVImin ) )**2

def _vapor_latent(LST):
    return ( 2.501 - 0.00236 *( LST - 273.15 )) * 10**6

def zenith_metric(DEM, Day, As, Sl, h, FileDir):
    '''
     This function models DEM effect on Evapotranspiration for METRIC method
     Inputs: DEM (2d double), Day (integer), four latitude coordinates
     Ouputs: Zenith_metric (2d double)
    '''
    #Declination of the Sun as seen from Earth [degree]
    declin = -23.45 * np.cos(np.deg2rad(360/365*(Day+10)))

    #The latitude of pixcels
    PixLat=LatMatrix(FileDir, )
    end=DEM.shape[0]*DEM.shape[1]
    save_0= As.shape[0]
    save_1= As.shape[1]
    As= As.flatten()

    for k in range(end):
        if np.isnan(As[k]):
            W= [As[k-1], As[k+1], As[k+2]]
            M=np.mean([i for i in W if not(np.isnan(i))])
            As[k]=M

    As=As.reshape((save_0, save_1))
    As = As-180
    cosZenith = ((np.sin(np.deg2rad(declin))*np.sin(np.deg2rad(PixLat))*np.cos(np.deg2rad(Sl))) - (np.sin(np.deg2rad(declin))*np.cos(np.deg2rad(PixLat))*np.sin(np.deg2rad(Sl))*np.cos(np.deg2rad(As))) + (np.cos(np.deg2rad(declin))* np.cos(np.deg2rad(PixLat))* np.cos(np.deg2rad(Sl)))+ (np.cos(np.deg2rad(declin))* np.sin(np.deg2rad(PixLat))* np.sin(np.deg2rad(Sl))* np.cos(np.deg2rad(As))) + (np.cos(np.deg2rad(declin))* np.sin(np.deg2rad(As))* np.sin(np.deg2rad(Sl))))
    return cosZenith

def LatMatrix(FileDir, ):
    '''
     to create a matrix of latitudes using 4 corners latitudes
     inputs: S1,S2: the size of matrix (row & column)
             UL,UR,LL,LR: the latitude of 4 corners

    Inputs changed!
    '''
    dataset = rasterio.open(FileDir.root+FileDir.band2)
    LATs = np.array([dataset.xy(i, j) for i in range(dataset.height) for j in range(dataset.width)])
    zone_number = META(FileDir).utm_zone
    LATs = np.array([utm.to_latlon(i, j, zone_number, 'U') for i, j in LATs])[:, 0]
    dataset.close()
    return LATs.reshape((dataset.shape[0], dataset.shape[1]))
