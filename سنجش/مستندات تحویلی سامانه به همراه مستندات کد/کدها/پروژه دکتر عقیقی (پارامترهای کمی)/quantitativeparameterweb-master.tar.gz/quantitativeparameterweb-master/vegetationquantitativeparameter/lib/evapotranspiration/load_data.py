from math import radians, pi, cos, exp
import numpy as np

from . import rs_mathematica as rs
from . import files_reader as reader

from .RasTerio import read_raster_as_array, read_as_raster


class Param(object):
    '''
    This  load ground data from an excel file.
    Required ground data includes temperature(minimum, maximum and mean of day in degrees centigrade),
    relative humidity, wind speed (daily mean in m/s, meter per second) ,
    actual sunhours, elevation and latitude of sensor node or meteorological station,
    '''

    def __init__(self, FileDir):
        excel_obj_as_dict=reader.read_excel_as_dict(sheetname=0, file_name=FileDir.ground_data, file_directory=FileDir.root)
        #Minimum Temperature in centigrade
        self.Tmin= excel_obj_as_dict['MinTemp']
        #Maximum Temperature in centigrade
        self.Tmax= excel_obj_as_dict['MaxTemp']
        #Mean Temperature in centigrade
        self.Tmean= (self.Tmin+self.Tmax)/2
        #elevation of meteorological station
        self.Elevation=excel_obj_as_dict['Elevation']
        #Actual Sunshine Hours
        self.ActualSunshine=excel_obj_as_dict['Actual_sunshine']
        #Relative Humidity (mean daily)
        self.RH=excel_obj_as_dict['RH']
        #Lat o long station
        self.Latitude=excel_obj_as_dict['latitude']
        self.longitude=excel_obj_as_dict["longitude"]
        self.LatDeg=excel_obj_as_dict["LatDeg"]
        self.LongDeg= excel_obj_as_dict["LongDeg"]
        #air temperature of satellite image date and time
        self.Tinst=excel_obj_as_dict['Satellite time air temp']
        #AirPressure of satellite image date and time
        self.AirPressureinst=excel_obj_as_dict["AirPressureinst"]
        #AirPressure
        self.AirPressure=excel_obj_as_dict["AirPressure"]
        #Wind Speed at 2 meter above ground (m/s, meter per second)
        self.WindSpeed=excel_obj_as_dict['wind_speed']
        #WindSpeed of satellite image date and time
        self.WindSpeedinst=excel_obj_as_dict["wind_speedins"]


class META(object):
    '''
    This function loads Metadata of Landsat 8 image and extract required parameters from it.
    Required parameters are radiance and reflectance coefficients, band 10 and 11 coefficients,
    zenith angle, eart - sun distance and julian day.
    Metadata is a text file in Landsat folder containing all required data for preprocessing of the Landsat image.
    '''
    def __init__(self, FileDir):
        meta=reader.convert_text_to_dict(file_name=FileDir.meta, file_directory=FileDir.root)
        #RADIANCE_ADD_BAND_n
        self.addradb2 =float(meta['RADIANCE_ADD_BAND_2'])
        self.addradb3 =float(meta['RADIANCE_ADD_BAND_3'])
        self.addradb4 =float(meta['RADIANCE_ADD_BAND_4'])
        self.addradb5 =float(meta['RADIANCE_ADD_BAND_5'])
        self.addradb6 =float(meta['RADIANCE_ADD_BAND_6'])
        self.addradb7 =float(meta['RADIANCE_ADD_BAND_7'])
        self.addradb10 =float(meta['RADIANCE_ADD_BAND_10'])
        self.addradb11 =float(meta['RADIANCE_ADD_BAND_11'])
        #RADIANCE_MULT_BAND_n
        self.multiradb2 =float(meta['RADIANCE_MULT_BAND_2'])
        self.multiradb3 =float(meta['RADIANCE_MULT_BAND_3'])
        self.multiradb4 =float(meta['RADIANCE_MULT_BAND_4'])
        self.multiradb5 =float(meta['RADIANCE_MULT_BAND_5'])
        self.multiradb6 =float(meta['RADIANCE_MULT_BAND_6'])
        self.multiradb7 =float(meta['RADIANCE_MULT_BAND_7'])
        self.multiradb10 =float(meta['RADIANCE_MULT_BAND_10'])
        self.multiradb11 =float(meta['RADIANCE_MULT_BAND_11'])
        #REFLECTANCE_ADD_BAND_n
        self.addrefb2 =float(meta['REFLECTANCE_ADD_BAND_2'])
        self.addrefb3 =float(meta['REFLECTANCE_ADD_BAND_3'])
        self.addrefb4 =float(meta['REFLECTANCE_ADD_BAND_4'])
        self.addrefb5 =float(meta['REFLECTANCE_ADD_BAND_5'])
        self.addrefb6 =float(meta['REFLECTANCE_ADD_BAND_6'])
        self.addrefb7 =float(meta['REFLECTANCE_ADD_BAND_7'])
        #REFLECTANCE_MULT_BAND_n
        self.multirefb2 =float(meta['REFLECTANCE_MULT_BAND_2'])
        self.multirefb3 =float(meta['REFLECTANCE_MULT_BAND_3'])
        self.multirefb4 =float(meta['REFLECTANCE_MULT_BAND_4'])
        self.multirefb5 =float(meta['REFLECTANCE_MULT_BAND_5'])
        self.multirefb6 =float(meta['REFLECTANCE_MULT_BAND_6'])
        self.multirefb7 =float(meta['REFLECTANCE_MULT_BAND_7'])
        #K1_CONSTANT_BAND_n
        self.k1b10 =float(meta['K1_CONSTANT_BAND_10'])
        self.k1b11 =float(meta['K1_CONSTANT_BAND_11'])
        self.k2b10 =float(meta['K2_CONSTANT_BAND_10'])
        self.k2b11 =float(meta['K2_CONSTANT_BAND_11'])
        #SUN_ELEVATION
        self.zenith =radians(90-float(meta['SUN_ELEVATION']))
        #EARTH_SUN_DISTANCE
        self.dr =(1/float(meta['EARTH_SUN_DISTANCE']))**2
        #LANDSAT_SCENE_ID
        #Meta.julianday = str2num(Meta.julianday(:,12:14));
        self.julianday =int(meta['LANDSAT_SCENE_ID'][13:16])
        self.Elevation=radians(float(meta["SUN_ELEVATION"]))

        self.CORNER_UL_LAT= float(meta['CORNER_UL_LAT_PRODUCT'])
        self.CORNER_UR_LAT= float(meta['CORNER_UR_LAT_PRODUCT'])
        self.CORNER_LL_LAT= float(meta['CORNER_LL_LAT_PRODUCT'])
        self.CORNER_LR_LAT= float(meta['CORNER_LR_LAT_PRODUCT'])
        self.Houre= int(meta['FILE_DATE'][meta['FILE_DATE'].find(':')-2: meta['FILE_DATE'].find(':')]) + int(meta['FILE_DATE'][meta['FILE_DATE'].find(':')+1: meta['FILE_DATE'].find(':')+3]) / 60
        self.utm_zone = int(meta['UTM_ZONE'])


class RasterBand(object):
    def __init__(self, FileDir):
        self.band2= read_as_raster(file_name=FileDir.band2, directory_address=FileDir.root)


class Band(object):
    """
    loads Landsat bands
    """
    def __init__(self, FileDir):

        self.band2=      read_raster_as_array(file_name=FileDir.band2,      directory_address=FileDir.root, band=1)
        self.band3=      read_raster_as_array(file_name=FileDir.band3,      directory_address=FileDir.root, band=1)
        self.band4=      read_raster_as_array(file_name=FileDir.band4,      directory_address=FileDir.root, band=1)
        self.band5=      read_raster_as_array(file_name=FileDir.band5,      directory_address=FileDir.root, band=1)
        self.band6=      read_raster_as_array(file_name=FileDir.band6,      directory_address=FileDir.root, band=1)
        self.band7=      read_raster_as_array(file_name=FileDir.band7,      directory_address=FileDir.root, band=1)
        self.band10=     read_raster_as_array(file_name=FileDir.band10,     directory_address=FileDir.root, band=1)
        self.band11=     read_raster_as_array(file_name=FileDir.band11,     directory_address=FileDir.root, band=1)
        self.dem=        read_raster_as_array(file_name=FileDir.dem,        directory_address=FileDir.root, band=1)
        self.fmask=      read_raster_as_array(file_name=FileDir.fmask,      directory_address=FileDir.root, band=1)
        self.land_cover= read_raster_as_array(file_name=FileDir.land_cover, directory_address=FileDir.root, band=1)

        self.As = reader.read_csv_as_numpy(file_name=FileDir.aspect, directory_address=FileDir.root)
        self.Sl = reader.read_csv_as_numpy(file_name=FileDir.slope,  directory_address=FileDir.root)

        #This section creates a mask for NaN value
        # self.band3[np.isnan(self.band2)]=  np.nan
        # self.band4[np.isnan(self.band2)]=  np.nan
        # self.band5[np.isnan(self.band2)]=  np.nan
        # self.band6[np.isnan(self.band2)]=  np.nan
        # self.band7[np.isnan(self.band2)]=  np.nan
        #
        # self.band2[np.isnan(self.band2)]=       0
        # self.band10[self.band10 == 0]=     np.nan
        # self.band11[self.band11 == 0]=     np.nan

        # self.band2[np.logical_or(self.fmask==2, self.fmask==4)]=np.nan
        # self.band3[np.logical_or(self.fmask==2, self.fmask==4)]=np.nan
        # self.band4[np.logical_or(self.fmask==2, self.fmask==4)]=np.nan
        # self.band5[np.logical_or(self.fmask==2, self.fmask==4)]=np.nan
        # self.band6[np.logical_or(self.fmask==2, self.fmask==4)]=np.nan
        # self.band7[np.logical_or(self.fmask==2, self.fmask==4)]=np.nan
        # self.band10[np.logical_or(self.fmask==2, self.fmask==4)]=np.nan
        # self.band11[np.logical_or(self.fmask==2, self.fmask==4)]=np.nan


class HotCold (object):
    '''
    This function reads hot and cold pixels latitude and longitude from excel
    file determined in brackets.
    Latitude and longitude of the pixels (in decimal degrees) should be inside study area.
    '''
    def __init__(self, FileDir):
        excel_obj_as_dict= read_excel_as_dict(file_name=FileDir.ground_data, file_directory=FileDir.root, sheetname=1)
        self.lats_cold =   excel_obj_as_dict['coldpixel_lat']
        self.longs_cold =  excel_obj_as_dict['coldpixel_long']
        self.lats_hot =    excel_obj_as_dict['hotpixel_lat']
        self.longs_hot =   excel_obj_as_dict['hotpixel_long']

class Radiance():
    def __init__(self, FileDir):
        #obj
        self.bands=Band(FileDir)
        self.Meta=META(FileDir)
        #Radiance bands:
        self.band10=rs.Conversion_pixel_DN_values_to_radiance(self.Meta.addradb10, self.Meta.multiradb10, self.bands.band10)
        self.band11=rs.Conversion_pixel_DN_values_to_radiance(self.Meta.addradb11, self.Meta.multiradb11, self.bands.band11)

class WeightingCoefficient(object):
    '''
    weighting coefficient for each band(Monitoring irrigation schemes,2014, Remote Sensing)
    '''
    def __init__(self):
        self.band2= 0.2935
        self.band3= 0.2738
        self.band4= 0.233
        self.band5= 0.1554
        self.band6= 0.0322
        self.band7= 0.0121

class Reflectance():
    def __init__(self, FileDir):
        #obj:
        self.bands=Band(FileDir)
        self.Meta=META(FileDir)

        #Reflectance bands:
        self.band2= rs.Conversion_from_Radiance_to_Reflectance(self.Meta.multirefb2, self.bands.band2, self.Meta.addrefb2, self.Meta.Elevation)
        self.band3= rs.Conversion_from_Radiance_to_Reflectance(self.Meta.multirefb3, self.bands.band3, self.Meta.addrefb3, self.Meta.Elevation)
        self.band4= rs.Conversion_from_Radiance_to_Reflectance(self.Meta.multirefb4, self.bands.band4, self.Meta.addrefb4, self.Meta.Elevation)
        self.band5= rs.Conversion_from_Radiance_to_Reflectance(self.Meta.multirefb5, self.bands.band5, self.Meta.addrefb5, self.Meta.Elevation)
        self.band6= rs.Conversion_from_Radiance_to_Reflectance(self.Meta.multirefb6, self.bands.band6, self.Meta.addrefb6, self.Meta.Elevation)
        self.band7= rs.Conversion_from_Radiance_to_Reflectance(self.Meta.multirefb7, self.bands.band7, self.Meta.addrefb7, self.Meta.Elevation)

class GeographicalCoordinates():
    def __init__(self, FileDir):
        #top-left
        self.xll = 47.4664039396
        self.yll = 39.8145784677
        #bottom-down
        self.xrd = 48.083
        self.yrd = 39.397
        #ref is refrence for rs_mathematica.ltln2val()
        self.ref= read_as_raster(FileDir.band2, directory_address=FileDir.root)

class Constants():
    def __init__(self):
        self.Es10= 0.9668
        self.Es11= 0.9747
        self.Ev10= 0.9863
        self.Ev11= 0.9896
        self.Fprim= 0.55
        self.NDVImin= 0.2
        self.NDVImax= 0.5

class ReflectanceMetric():
    def __init__(self, FileDir):
        #obj:
        self.bands=Band(FileDir)
        self.Meta=META(FileDir)

        self.band2 =( self.Meta.multirefb2 * self.bands.band2 + self.Meta.addrefb2 ) / ( np.sin( self.Meta.Elevation - np.deg2rad(self.bands.Sl) ))
        self.band3 =( self.Meta.multirefb3 * self.bands.band3 + self.Meta.addrefb3 ) / ( np.sin( self.Meta.Elevation - np.deg2rad(self.bands.Sl) ))
        self.band4 =( self.Meta.multirefb4 * self.bands.band4 + self.Meta.addrefb4 ) / ( np.sin( self.Meta.Elevation - np.deg2rad(self.bands.Sl) ))
        self.band5 =( self.Meta.multirefb5 * self.bands.band5 + self.Meta.addrefb5 ) / ( np.sin( self.Meta.Elevation - np.deg2rad(self.bands.Sl) ))
        self.band6 =( self.Meta.multirefb6 * self.bands.band6 + self.Meta.addrefb6 ) / ( np.sin( self.Meta.Elevation - np.deg2rad(self.bands.Sl) ))
        self.band7 =( self.Meta.multirefb7 * self.bands.band7 + self.Meta.addrefb7 ) / ( np.sin( self.Meta.Elevation - np.deg2rad(self.bands.Sl) ))


class FileDir():
    def __init__(self,
                 root,
                 ground_data,
                 band2,
                 band3,
                 band4,
                 band5,
                 band6,
                 band7,
                 band10,
                 band11,
                 meta,
                 fmask,
                 dem,
                 land_cover,
                 slope,
                 aspect,):

        self.root = str(root)
        self.ground_data = str(ground_data)
        self.band2 = str(band2)
        self.band3 = str(band3)
        self.band4 = str(band4)
        self.band5 = str(band5)
        self.band6 = str(band6)
        self.band7 = str(band7)
        self.band10 = str(band10)
        self.band11 = str(band11)
        self.meta = str(meta)
        self.fmask = str(fmask)
        self.dem = str(dem)
        self.land_cover = str(land_cover)
        self.slope = str(slope)
        self.aspect = str(aspect)


class ET_10_Params():

    def __init__(self):
        # Elevation (m)
        self.DEM = 0
        # Temperature (C)
        self.T = 22.0
        # Minimum Temperature (C)
        self.Tmin = 16.5
        # Maximum Temperature (C)
        self.Tmax = 28
        # Latitude
        self.Lat = 39.6075
        # Relative humidity
        self.RH = 0.79
        # AirPressure (kPa)
        self.P = 100.15
        # wind spped (m/s)
        self.U2 = 3
        # day of year  (1-365)
        self.DOY = 146
        # time (hour: 0-24)
        self.hr = 12
        # time (minute: 1-60)
        self.Min = 47
        # mean daily percentage of annual daytime hours (0.2> in Iran <0.34)
        self.PerSun = 0.3
        # Land surface temperature
        self.LST = 0
        # between 0-1
        self.NDVI = 0
        # cloudiness coefficient (<= 1)
        self.RsRs0 = 0.97
