#standard libs import
import unittest
import numpy as npy
from numpy.testing import assert_allclose as np_assert_allclose


TEST_DIR="evapotranspiration/packages/landsat8/test_files/LC08_L1TP_165035_20170630_20170630_01_RT_MTL/"

def read_csv_as_numpy(file_name, sub_dir, root_dir=TEST_DIR):
    file_dir=root_dir+sub_dir
    csv = npy.genfromtxt (file_dir+file_name, delimiter=",")
    return csv


class TestLoadData(unittest.TestCase):
    #
    # def test_param(self):
    #     #import and make object
    #     # from load_data import Param
    #     # p=Param()
    #     #
    #     # #testing
    #     # self.assertEqual(p.Tmin, 21.4)
    #     # self.assertEqual(p.Tmax, 36.5)
    #     # self.assertEqual(p.RH, 0.65)
    #     # self.assertEqual(p.Latitude, 39.576)
    #     # self.assertEqual(p.t, 32.2)

    def test_Radiance(self):
        #import and make object
        from load_data import Radiance
        rad=Radiance()

        #file directory
        sub_dir='loaddata/radiance/'

        #read test file
        # radianceband2= read_csv_as_numpy('radianceband2.csv', sub_dir)
        # radianceband3= read_csv_as_numpy('radianceband3.csv', sub_dir)
        # radianceband4= read_csv_as_numpy('radianceband4.csv', sub_dir)
        # radianceband5= read_csv_as_numpy('radianceband5.csv', sub_dir)
        # radianceband6= read_csv_as_numpy('radianceband6.csv', sub_dir)
        # radianceband7= read_csv_as_numpy('radianceband7.csv', sub_dir)
        radianceband10= read_csv_as_numpy('Radiance.band10.csv', sub_dir)
        radianceband11= read_csv_as_numpy('Radiance.band11.csv', sub_dir)

        #testing, rtol=1e-3 -> 3 floating point
        # np_assert_allclose(rad.band2, radianceband2, rtol=1e-3)
        # np_assert_allclose(rad.band3, radianceband3, rtol=1e-3)
        # np_assert_allclose(rad.band4, radianceband4, rtol=1e-3)
        # np_assert_allclose(rad.band5, radianceband5, rtol=1e-3)
        # np_assert_allclose(rad.band6, radianceband6, rtol=1e-3)
        # np_assert_allclose(rad.band7, radianceband7, rtol=1e-3)
        np_assert_allclose(rad.band10, radianceband10, rtol=1e-3)
        np_assert_allclose(rad.band11, radianceband11, rtol=1e-3)


    def test_reflectance(self):
        #import and make object
        from load_data import Reflectance
        r=Reflectance()

        #file directory
        sub_dir='loaddata/reflectance/'

        #read test file
        reflectance2= read_csv_as_numpy("Reflectance.band2.csv", sub_dir)
        reflectance3= read_csv_as_numpy("Reflectance.band3.csv", sub_dir)
        reflectance4= read_csv_as_numpy("Reflectance.band4.csv", sub_dir)
        reflectance5= read_csv_as_numpy("Reflectance.band5.csv", sub_dir)
        reflectance6= read_csv_as_numpy("Reflectance.band6.csv", sub_dir)
        reflectance7= read_csv_as_numpy("Reflectance.band7.csv", sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(r.band2, reflectance2, rtol=1e-4)
        np_assert_allclose(r.band3, reflectance3, rtol=1e-4)
        np_assert_allclose(r.band4, reflectance4, rtol=1e-4)
        np_assert_allclose(r.band5, reflectance5, rtol=1e-4)
        np_assert_allclose(r.band6, reflectance6, rtol=1e-4)
        np_assert_allclose(r.band7, reflectance7, rtol=1e-4)

    def test_bands(self):
        from load_data import Band
        b=Band()

        #file directory
        sub_dir='loaddata/bands/'

        #read test file
        band2= read_csv_as_numpy("Band2.csv", sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(b.band2, band2, rtol=1e-4)

#     def test_meta(self):
#         #import and make object
#         from load_data import META
#         from math import radians
#         m=META()
#
#         #tesing
#         self.assertEqual(m.addradb7, -2.49577)
#         self.assertEqual(m.addrefb5, -0.100000)
#         self.assertEqual(m.dr, (1/ 1.0132573)**2)
#         self.assertEqual(m.julianday,225)
#         self.assertEqual(m.k1b11,  480.8883)
#         self.assertEqual(m.k2b11, 1201.1442)
#         self.assertEqual(m.zenith, radians(90-59.39075572))
#
#     def test_weighting_coefficient(self):
#         #import and make object
#         from load_data import WeightingCoefficient
#         w=WeightingCoefficient()
#
#         #testing
#         self.assertEqual(w.band3, 0.2738)
#         self.assertEqual(w.band7,  0.0121)
#
#
#     def test_hot_cold(self):
#         #import and make object
#         from load_data import HotCold
#         hc=HotCold()
#
#         #testing
#         self.assertEqual(hc.lats_hot, 39.503)
#         self.assertEqual(hc.longs_cold, 47.802)


class TestRsMathematica(unittest.TestCase):

    def test__albedo_top_atmosphere(self):
        #file directory
        sub_dir='rs_mathematica/albedotoa/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_albedotoa.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_albedotoa.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test__albedo(self):
        #file directory
        sub_dir='rs_mathematica/albedo/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_albedo.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_albedo.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_Transmissivity(self):
        #file directory
        sub_dir='rs_mathematica/AtmosphericTransmissivity/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_AtmosphericTransmissivity.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_AtmosphericTransmissivity.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_ndvii(self):
        #file directory
        sub_dir='rs_mathematica/ndvi/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_NDVI.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_NDVI.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_NDWI7(self):
        #file directory
        sub_dir='rs_mathematica/NDWI7/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_NDWI7.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_NDWI7.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_NDWI6(self):
        #file directory
        sub_dir='rs_mathematica/NDWI6/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_NDWI6.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_NDWI6.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_Emissiv_1(self):
        #file directory
        sub_dir='rs_mathematica/Emissiv_1/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_Emissiv_1.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_Emissiv_1.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_Emissiv_210(self):
        #file directory
        sub_dir='rs_mathematica/Emissiv_210/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_Emissiv_210.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_Emissiv_210.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_Emissiv_211(self):
        #file directory
        sub_dir='rs_mathematica/Emissiv_211/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_Emissiv_211.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_Emissiv_211.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_emissivity10(self):
        #file directory
        sub_dir='rs_mathematica/emissivity10/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_emissivity10.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_emissivity10.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_emissivity11(self):
        #file directory
        sub_dir='rs_mathematica/emissivity11/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_emissivity11.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_emissivity11.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)


    def test_LST1_10(self):
        #file directory
        sub_dir='rs_mathematica/LST1_10/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST1_10.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST1_10.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LST1_11(self):
        #file directory
        sub_dir='rs_mathematica/LST1_11/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST1_11.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST1_11.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LST2_10(self):
        #file directory
        sub_dir='rs_mathematica/LST2_10/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST2_10.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST2_10.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)


    def test_LST2_11(self):
        #file directory
        sub_dir='rs_mathematica/LST2_11/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST2_11.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST2_11.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LST3_10(self):
        #file directory
        sub_dir='rs_mathematica/LST3_10/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST3_10.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST3_10.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LST3_11(self):
        #file directory
        sub_dir='rs_mathematica/LST3_11/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST3_11.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST3_11.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LST0_10(self):
        #file directory
        sub_dir='rs_mathematica/LST0_10/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST0_10.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST0_10.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LST0_11(self):
        #file directory
        sub_dir='rs_mathematica/LST0_11/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST0_11.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST0_11.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LongWaveOutward(self):
        #file directory
        sub_dir='rs_mathematica/LongWaveOutward/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LongWaveOutward.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LongWaveOutward.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_avefil(self):
        #file directory
        sub_dir='rs_mathematica/albedo_avefil/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_avefil.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_avefil.csv', sub_dir)

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_ndvimask_ave(self):
        #file directory
        sub_dir='rs_mathematica/ndvimask_ave/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_ndvimask_ave.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_ndvimask_ave.csv', sub_dir)
        #
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)


    def test_ndvimask_stdv(self):
        #file directory
        sub_dir='rs_mathematica/ndvimask_stdv/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_ndvimask_stdv.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_ndvimask_stdv.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)


    def test_ndvimask_cv(self):
        #file directory
        sub_dir='rs_mathematica/ndvimask_cv/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_ndvimask_cv.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_ndvimask_cv.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_ndvimask(self):
        #file directory
        sub_dir='rs_mathematica/ndvi_mask/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_ndvi_mask.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_ndvi_mask.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)


    def test_classmask1(self):
        #file directory
        sub_dir='rs_mathematica/classmask1/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_classmask1.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_classmask1.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)


    def test_classmask1(self):
        #file directory
        sub_dir='rs_mathematica/classfilt_circlePixels/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_circlePixels.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_circlePixels.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_classmask(self):
        #file directory
        sub_dir='rs_mathematica/classmask/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_classmask.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_classmask.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LST_mask_std(self):
        #file directory
        sub_dir='rs_mathematica/LST_mask_std/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST_mask_std.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST_mask_std.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_LST_mask(self):
        #file directory
        sub_dir='rs_mathematica/LST_mask/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_LST_mask.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_LST_mask.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)


    def test_matlab_Fmaskk(self):
        #file directory
        sub_dir='rs_mathematica/Fmaskk/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_Fmaskk.csv', sub_dir)

        #read python output
        py_arr= read_csv_as_numpy('python_Fmaskk.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])

        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    def test_new(self):
        #file directory
        sub_dir='rs_mathematica/new/'

        #read test file
        ndvi1= read_csv_as_numpy('NDVI_mask.csv', sub_dir)
        ndvi2= read_csv_as_numpy('NDVI_mask2.csv', sub_dir)
        ndvi3= read_csv_as_numpy('NDVI_mask3.csv', sub_dir)

        print("dsa")
        # np_assert_allclose(ndvi1, ndvi2, rtol=1e-4)
        # np_assert_allclose(ndvi3, ndvi2, rtol=1e-4)
        np_assert_allclose(ndvi3, ndvi1, rtol=1e-4)




    def test_Hot_map(self):
        #file directory
        sub_dir='rs_mathematica/Hot_map/'

        #read test file
        test_arr= read_csv_as_numpy('matlab_edgesN_h.csv', sub_dir)
        #read python output
        py_arr= read_csv_as_numpy('python_edgesN_h.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])
        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

        #read test file
        test_arr= read_csv_as_numpy('matlab_edgesL_h.csv', sub_dir)
        #read python output
        py_arr= read_csv_as_numpy('python_edgesL_h.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        #
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])
        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

        #read test file
        test_arr= read_csv_as_numpy('matlab_NL_h.csv', sub_dir)
        #read python output
        py_arr= read_csv_as_numpy('python_NL_h.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])
        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

        #read test file
        test_arr= read_csv_as_numpy('matlab_Nna_h.csv', sub_dir)
        #read python output
        py_arr= read_csv_as_numpy('python_Nna_h.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])
        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)


        #read test file
        test_arr= read_csv_as_numpy('matlab_NLa_h.csv', sub_dir)
        #read python output
        py_arr= read_csv_as_numpy('python_NLa_h.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])
        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

        #read test file
        test_arr= read_csv_as_numpy('matlab_Hot_map.csv', sub_dir)
        #read python output
        py_arr= read_csv_as_numpy('python_Hot_map.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])
        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

        #read test file
        test_arr= read_csv_as_numpy('matlab_LSTrange_h.csv', sub_dir)
        #read python output
        py_arr= read_csv_as_numpy('python_LSTrange_h.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])
        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

        #read test file
        test_arr= read_csv_as_numpy('matlab_hotRange.csv', sub_dir)
        #read python output
        py_arr= read_csv_as_numpy('python_hotRange.csv', sub_dir)
        # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # print(m)
        # print(test_arr[m])
        # print(py_arr[m])
        #testing, rtol=1e-4 -> 4 floating point
        np_assert_allclose(py_arr, test_arr, rtol=1e-4)

        # #read test file
        # test_arr= read_csv_as_numpy('matlab_hot_select.csv', sub_dir)
        # #read python output
        # py_arr= read_csv_as_numpy('python_hot_select.csv', sub_dir)
        # # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
        # # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
        # # print(m)
        # # print(test_arr[m])
        # # print(py_arr[m])
        # #testing, rtol=1e-4 -> 4 floating point
        # np_assert_allclose(py_arr, test_arr, rtol=1e-4)



    # def test_Sum_filt(self):
    #     #file directory
    #     sub_dir='rs_mathematica/Sum_filt/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('matlab_Sum_filt.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('python_Sum_filt.csv', sub_dir)
    #     # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     #
    #     # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
    #     # print(m)
    #     # print(test_arr[m])
    #     # print(py_arr[m])
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)
    #
    #
    # def test_finalmask(self):
    #     #file directory
    #     sub_dir='rs_mathematica/finalmask/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('matlab_finalmask.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('python_finalmask.csv', sub_dir)
    #     # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     #
    #     # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
    #     # print(m)
    #     # print(test_arr[m])
    #     # print(py_arr[m])
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    # def test_Hot_map(self):
    #     #file directory
    #     sub_dir='rs_mathematica/Hot_map/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('matlab_Lstfin1.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('python_Lstfin1.csv', sub_dir)
    #     # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     #
    #     m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
    #     print(m)
    #     print(test_arr[m])
    #     print(py_arr[m])
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    # def test_Albedo_cv(self):
    #     #file directory
    #     sub_dir='rs_mathematica/albedo_cv/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('matlab_albedo_cv.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('python_albedo_cv.csv', sub_dir)
    #
    #
    #     # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     #
    #     # m=npy.where(~npy.isclose(test_arr, py_arr, rtol=1e-4))
    #     # print(m)
    #     # print(test_arr[m])
    #     # print(py_arr[m])
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)
    #



    # def test_Albedo_mask(self):
    #     #file directory
    #     sub_dir='rs_mathematica/Albedo_mask/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('matlab_Albedo_mask.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('python_Albedo_mask.csv', sub_dir)
    #
    #     #testing, rtol=1e-4 -> 4 floating point
        # np_assert_allclose(py_arr, test_arr, rtol=1e-2)
    #
    #
    # def test_albedo_stdv(self):
    #     #file directory
    #     sub_dir='rs_mathematica/albedo_stdv/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('matlab_stdv.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('python_stdv.csv', sub_dir)
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)



if __name__=="__main__":
    unittest.main()
