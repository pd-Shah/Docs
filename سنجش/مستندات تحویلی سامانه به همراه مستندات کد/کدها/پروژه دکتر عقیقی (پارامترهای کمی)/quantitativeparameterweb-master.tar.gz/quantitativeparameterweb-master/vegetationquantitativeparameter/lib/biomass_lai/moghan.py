from .index.index import Index


class Maize():

    @staticmethod
    def lai(red, swir1, swir2, blue, lai1, lai2, lai3):

        B4B12 = Index.diff_index(red, swir2)
        B2dB11 = Index.ratio_index(blue, swir1)
        B4dB11 = Index.ratio_index(red, swir1)

        lai_maize1 = Index.lai(B4B12, lai1[0], lai1[1])
        lai_maize2 = Index.lai(B2dB11, lai2[0], lai2[1])
        lai_maize3 = Index.lai(B4dB11, lai3[0], lai3[1])

        return lai_maize1, lai_maize2, lai_maize3

    @staticmethod
    def wet_biomass(red, red_edge_5, swir1, wet1, wet2, wet3, ):

        B5dB11 = Index.ratio_index(red_edge_5, swir1)
        B5B11 = Index.diff_index(red_edge_5, swir1)
        B4B11 = Index.diff_index(red, swir1)

        wet_biomass_maize1 = Index.wet_biomass(B5dB11, wet1[0], wet1[1])
        wet_biomass_maize2 = Index.wet_biomass(B5B11, wet2[0], wet2[1])
        wet_biomass_maize3 = Index.wet_biomass(B4B11, wet3[0], wet3[1])

        return wet_biomass_maize1, wet_biomass_maize2, wet_biomass_maize3

    @staticmethod
    def dry_biomass(red, swir1, red_edge_5, dry1, dry2, dry3):

        B4B11 = Index.diff_index(red, swir1)
        B5dB11 = Index.ratio_index(red_edge_5, swir1)
        B5B11 = Index.diff_index(red_edge_5, swir1)

        dry_biomass_maize1 = Index.dry_biomass(B4B11, dry1[0], dry1[1])
        dry_biomass_maize2 = Index.dry_biomass(B5dB11, dry2[0], dry2[1])
        dry_biomass_maize3 = Index.dry_biomass(B5B11, dry3[0], dry3[1])

        return dry_biomass_maize1, dry_biomass_maize2, dry_biomass_maize3


class Alfalfa():

    @staticmethod
    def lai(red_edge_6, narrow_nir, lai1, lai2, lai3, ):

        B6B8A = Index.diff_index(red_edge_6, narrow_nir)
        B6dB8A = Index.ratio_index(red_edge_6, narrow_nir)
        NB6B8A = Index.normalized_index(red_edge_6, narrow_nir)

        lai_alfalfa1 = Index.lai(B6B8A, lai1[0], lai1[1])
        lai_alfalfa2 = Index.lai(B6dB8A, lai2[0], lai2[1])
        lai_alfalfa3 = Index.lai(NB6B8A, lai3[0], lai3[1])

        return lai_alfalfa1, lai_alfalfa2, lai_alfalfa3

    @staticmethod
    def wet_biomass(red_edge_5, narrow_nir, nir, red, wet1, wet2, wet3, ):

        B5B8 = Index.diff_index(red_edge_5, nir)
        B4B8A = Index.diff_index(red, narrow_nir)
        B4B8 = Index.diff_index(red, nir)

        wet_biomass_alfalfa1 = Index.wet_biomass(B5B8, wet1[0], wet1[1])
        wet_biomass_alfalfa2 = Index.wet_biomass(B4B8A, wet2[0], wet2[1])
        wet_biomass_alfalfa3 = Index.wet_biomass(B4B8, wet3[0], wet3[1])

        return wet_biomass_alfalfa1, wet_biomass_alfalfa2, wet_biomass_alfalfa3

    @staticmethod
    def dry_biomass(red, nir, red_edge_5, narrow_nir, dry1, dry2, dry3, ):

        B4B8 = Index.diff_index(red, nir)
        B5B8 = Index.diff_index(red_edge_5, nir)
        B4B8A = Index.diff_index(red, narrow_nir)

        dry_biomass_alfalfa1 = Index.dry_biomass(B4B8, dry1[0], dry1[1])
        dry_biomass_alfalfa2 = Index.dry_biomass(B5B8, dry2[0], dry2[1])
        dry_biomass_alfalfa3 = Index.dry_biomass(B4B8A, dry3[0], dry3[1])

        return dry_biomass_alfalfa1, dry_biomass_alfalfa2, dry_biomass_alfalfa3


class Moghan(Alfalfa, Maize):

    def run(self,
            blue,
            green,
            narrow_nir,
            nir,
            red,
            red_edge_5,
            red_edge_6,
            red_edge_7,
            swir_1,
            swir_2,
            maize_lai1,
            maize_lai2,
            maize_lai3,
            maize_wet1,
            maize_wet2,
            maize_wet3,
            maize_dry1,
            maize_dry2,
            maize_dry3,
            alfalfa_lai1,
            alfalfa_lai2,
            alfalfa_lai3,
            alfalfa_wet1,
            alfalfa_wet2,
            alfalfa_wet3,
            alfalfa_dry1,
            alfalfa_dry2,
            alfalfa_dry3, ):

        maize_lai = Maize.lai(
                            red=red,
                            swir1=swir_1,
                            swir2=swir_2,
                            blue=blue,
                            lai1=maize_lai1,
                            lai2=maize_lai2,
                            lai3=maize_lai3,
        )

        maize_wet_biomass = Maize.wet_biomass(
                                red=red,
                                red_edge_5=red_edge_5,
                                swir1=swir_1,
                                wet1=maize_wet1,
                                wet2=maize_wet2,
                                wet3=maize_wet3,
        )

        maize_dry_biomass = Maize.dry_biomass(
                                red=red,
                                swir1=swir_1,
                                red_edge_5=red_edge_5,
                                dry1=maize_dry1,
                                dry2=maize_dry2,
                                dry3=maize_dry3,
        )

        alfalfa_lai = Alfalfa.lai(
                        red_edge_6=red_edge_6,
                        narrow_nir=narrow_nir,
                        lai1=alfalfa_lai1,
                        lai2=alfalfa_lai2,
                        lai3=alfalfa_lai3,
        )

        alfalfa_wet_biomass = Alfalfa.wet_biomass(
                                    red_edge_5=red_edge_5,
                                    narrow_nir=narrow_nir,
                                    nir=nir,
                                    red=red,
                                    wet1=alfalfa_wet1,
                                    wet2=alfalfa_wet2,
                                    wet3=alfalfa_wet3,
        )

        alfalfa_dry_biomass = Alfalfa.dry_biomass(
                                    red=red,
                                    nir=nir,
                                    red_edge_5=red_edge_5,
                                    narrow_nir=narrow_nir,
                                    dry1=alfalfa_dry1,
                                    dry2=alfalfa_dry2,
                                    dry3=alfalfa_dry3,
        )

        return {
                'alfalfa_dry_biomass': alfalfa_dry_biomass,
                'alfalfa_lai': alfalfa_lai,
                'alfalfa_wet_biomass': alfalfa_wet_biomass,
                'maize_dry_biomass': maize_dry_biomass,
                'maize_lai': maize_lai,
                'maize_wet_biomass': maize_wet_biomass,
        }
