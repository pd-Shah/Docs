import rasterio
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error

from .algs.algorithm import Algorithm


def alfalfa_dry_biomass(red_edge_5, nir, red, y):
    '''
    alfalfa_dry_biomass
    '''

    alfalfa_dry_biomass = Algorithm()

    # red_edge_5 = alfalfa_dry_biomass.read_file(
    #     Rededge5,
    # )
    #
    # nir = alfalfa_dry_biomass.read_file(
    #     NIR,
    # )
    #
    # red = alfalfa_dry_biomass.read_file(
    #     Red,
    # )
    #
    # y = alfalfa_dry_biomass.read_file(
    #     alfalfa_dry_biomass_result,
    # )

    X_train, X_test, y_train, y_test = alfalfa_dry_biomass.make_Xy_ready(
        (red_edge_5,
         nir,
         red),
        y,
    )

    decesition_tree = alfalfa_dry_biomass.decesition_tree(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    gussian_process_regresion = alfalfa_dry_biomass.gussian_process_regresion(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    random_forest = alfalfa_dry_biomass.random_forest(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    svr = alfalfa_dry_biomass.svr(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    result = {}
    result['decesition_tree'] = decesition_tree
    result['gussian_process_regresion'] = gussian_process_regresion
    result['random_forest'] = random_forest
    result['svr'] = svr

    return result


def alfalfa_lai(narrow_nir, swir_1, red_edge_7, y):

    alfalfa_lai = Algorithm()

    # narrow_nir = alfalfa_lai.read_file(
    #     NarrowNIR,
    # )
    #
    # swir_1 = alfalfa_lai.read_file(
    #     SWIR_1,
    # )
    #
    # red_edge_7 = alfalfa_lai.read_file(
    #     Rededge7,
    # )
    #
    # y = alfalfa_lai.read_file(
    #     alfalfa_lai_result,
    # )

    X_train, X_test, y_train, y_test = alfalfa_lai.make_Xy_ready(
        (narrow_nir,
         swir_1,
         red_edge_7),
        y,
    )

    decesition_tree = alfalfa_lai.decesition_tree(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    gussian_process_regresion = alfalfa_lai.gussian_process_regresion(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    random_forest = alfalfa_lai.random_forest(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    svr = alfalfa_lai.svr(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    result = {}
    result['decesition_tree'] = decesition_tree
    result['gussian_process_regresion'] = gussian_process_regresion
    result['random_forest'] = random_forest
    result['svr'] = svr

    return result


def alfalfa_wet_biomass(narrow_nir, swir_1, swir_2, red_edge_7, y):

    wet_biomass = Algorithm()

    # narrow_nir = wet_biomass.read_file(
    #     NarrowNIR,
    # )
    #
    # swir_1 = wet_biomass.read_file(
    #     SWIR_1,
    # )
    #
    # swir_2 = wet_biomass.read_file(
    #     SWIR_2,
    # )
    #
    # red_edge_7 = wet_biomass.read_file(
    #     Rededge7,
    # )
    #
    # y = wet_biomass.read_file(
    #     alfalfa_wet_biomass_result,
    # )

    X_train, X_test, y_train, y_test = wet_biomass.make_Xy_ready(
        (narrow_nir,
         swir_1,
         swir_2,
         red_edge_7),
        y,
    )

    decesition_tree = wet_biomass.decesition_tree(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    gussian_process_regresion = wet_biomass.gussian_process_regresion(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    random_forest = wet_biomass.random_forest(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    svr = wet_biomass.svr(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    result = {}
    result['decesition_tree'] = decesition_tree
    result['gussian_process_regresion'] = gussian_process_regresion
    result['random_forest'] = random_forest
    result['svr'] = svr

    return result


def maize_dry_biomass(red_edge_6, red_edge_7, nir, narrow_nir, swir_1, y):

    maize_dry_biomass = Algorithm()

    # red_edge_6 = maize_dry_biomass.read_file(
    #     Rededge6,
    # )
    #
    # red_edge_7 = maize_dry_biomass.read_file(
    #     Rededge7,
    # )
    #
    # nir = maize_dry_biomass.read_file(
    #     NIR,
    # )
    #
    # narrow_nir = maize_dry_biomass.read_file(
    #     NarrowNIR,
    # )
    #
    # swir_1 = maize_dry_biomass.read_file(
    #     SWIR_1,
    # )
    #
    # y = maize_dry_biomass.read_file(
    #     maize_dry_biomass_result,
    # )

    X_train, X_test, y_train, y_test = maize_dry_biomass.make_Xy_ready(
        (red_edge_6,
         red_edge_7,
         nir,
         narrow_nir,
         swir_1),
        y,
    )

    decesition_tree = maize_dry_biomass.decesition_tree(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    gussian_process_regresion = maize_dry_biomass.gussian_process_regresion(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    random_forest = maize_dry_biomass.random_forest(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    svr = maize_dry_biomass.svr(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    result = {}
    result['decesition_tree'] = decesition_tree
    result['gussian_process_regresion'] = gussian_process_regresion
    result['random_forest'] = random_forest
    result['svr'] = svr

    return result


def maize_lai(red_edge_6, red_edge_7, swir_1, narrow_nir, y):

    maize_lai = Algorithm()

    # red_edge_6 = maize_lai.read_file(
    #     Rededge6,
    # )
    #
    # red_edge_7 = maize_lai.read_file(
    #     Rededge7,
    # )
    #
    # swir_1 = maize_lai.read_file(
    #     SWIR_1,
    # )
    #
    # narrow_nir = maize_lai.read_file(
    #     NarrowNIR,
    # )
    #
    # y = maize_lai.read_file(
    #     maize_lai_result,
    # )

    X_train, X_test, y_train, y_test = maize_lai.make_Xy_ready(
        (red_edge_6,
         red_edge_7,
         swir_1,
         narrow_nir),
        y,
    )

    decesition_tree = maize_lai.decesition_tree(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    gussian_process_regresion = maize_lai.gussian_process_regresion(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    random_forest = maize_lai.random_forest(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    svr = maize_lai.svr(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    result = {}
    result['decesition_tree'] = decesition_tree
    result['gussian_process_regresion'] = gussian_process_regresion
    result['random_forest'] = random_forest
    result['svr'] = svr

    return result


def maize_wet_biomass(swir_1, narrow_nir, nir, red_edge_7, y):

    maize_wet_biomass = Algorithm()

    # swir_1 = maize_wet_biomass.read_file(
    #     SWIR_1,
    # )
    #
    # narrow_nir = maize_wet_biomass.read_file(
    #     NarrowNIR,
    # )
    #
    # nir = maize_wet_biomass.read_file(
    #     NIR,
    # )
    #
    # red_edge_7 = maize_wet_biomass.read_file(
    #     Rededge7,
    # )
    #
    # y = maize_wet_biomass.read_file(
    #     maize_wet_biomass_result,
    # )

    X_train, X_test, y_train, y_test = maize_wet_biomass.make_Xy_ready(
        (swir_1,
         narrow_nir,
         nir,
         red_edge_7),
        y,
    )

    decesition_tree = maize_wet_biomass.decesition_tree(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    gussian_process_regresion = maize_wet_biomass.gussian_process_regresion(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    random_forest = maize_wet_biomass.random_forest(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    svr = maize_wet_biomass.svr(
        X_train,
        X_test,
        y_train,
        y_test,
    )

    result = {}
    result['decesition_tree'] = decesition_tree
    result['gussian_process_regresion'] = gussian_process_regresion
    result['random_forest'] = random_forest
    result['svr'] = svr

    return result


if __name__ == '__main__':
    alfalfa_dry_biomass_result = '/home/aras/machine-learning/files/Y/alfalfa_dry_biomass_result.tif'
    alfalfa_lai_result = '/home/aras/machine-learning/files/Y/alfalfa_lai_result.tif'
    alfalfa_wet_biomass_result = '/home/aras/machine-learning/files/Y/alfalfa_wet_biomass_result.tif'
    maize_dry_biomass_result = '/home/aras/machine-learning/files/Y/maize_dry_biomass_result.tif'
    maize_lai_result = '/home/aras/machine-learning/files/Y/maize_lai_result.tif'
    maize_wet_biomass_result = '/home/aras/machine-learning/files/Y/maize_wet_biomass_result.tif'

    Blue = '/home/aras/machine-learning/files/X/Blue.tif'
    Green = '/home/aras/machine-learning/files/X/Green.tif'
    NarrowNIR = '/home/aras/machine-learning/files/X/NarrowNIR.tif'
    NIR = '/home/aras/machine-learning/files/X/NIR.tif'
    Red = '/home/aras/machine-learning/files/X/Red.tif'
    Rededge5 = '/home/aras/machine-learning/files/X/Rededge5.tif'
    Rededge6 = '/home/aras/machine-learning/files/X/Rededge6.tif'
    Rededge7 = '/home/aras/machine-learning/files/X/Rededge7.tif'
    SWIR_1 = '/home/aras/machine-learning/files/X/SWIR_1.tif'
    SWIR_2 = '/home/aras/machine-learning/files/X/SWIR_2.tif'

    alfalfa_dry_biomass = alfalfa_dry_biomass(Rededge5, NIR, Red, alfalfa_dry_biomass_result)
    print("alfalfa_dry_biomass ok ")
    alfalfa_lai = alfalfa_lai(NarrowNIR, SWIR_1, Rededge7, alfalfa_lai_result)
    print("alfalfa_lai ok ")
    alfalfa_wet_biomass = alfalfa_wet_biomass(NarrowNIR, SWIR_1, SWIR_2, Rededge7, alfalfa_wet_biomass_result)
    print("alfalfa_wet_biomass ok ")
    maize_dry_biomass = maize_dry_biomass(Rededge6, Rededge7, NIR, NarrowNIR, SWIR_1, maize_dry_biomass_result)
    print("maize_dry_biomass ok ")
    maize_lai = maize_lai(Rededge6, Rededge7, SWIR_1, NarrowNIR, maize_lai_result)
    print("maize_lai ok ")
    maize_wet_biomass = maize_wet_biomass(SWIR_1, NarrowNIR, NIR, Rededge7, maize_wet_biomass_result)
    print("maize_wet_biomass ok ")
