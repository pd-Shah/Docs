from scipy.ndimage.filters import generic_filter
import numpy as np
import rasterio

# I_filt = generic_filter([[0,1,2,3,4], [0,1,2,3,4], [0,1,2,3,4]], np.std, size=3)

dataset = rasterio.open('files/input/20170527/LC08_L1TP_167033_20170527_20170527_01_RT_B2.TIF')

print( range(dataset.height) )
print( range(dataset.width) )

x=np.array([dataset.ul(i, j) for i in range(dataset.height) for j in range(dataset.width)])[:, 0]

print(x.shape)
