import numpy as np

from .base import Base


class Index(Base):

    @staticmethod
    def ci_green(green, red_edge_7):
        '''
        Calculate CIgreen Index
            Inputs: green Band,red_edge_7 Band.
            Outputs: CIgreen Index (Double or float)
        '''
        return Base.index_v1(red_edge_7, green)

    @staticmethod
    def ci_red_edge(red_edge_7, red_edge_5):
        '''
        Calculate CIrededge Index
            Inputs: red_edge_5 Band, red_edge_7 Band.
            Outputs: CIredege Index (Double or float)
        '''
        return Base.index_v1(red_edge_7, red_edge_5)

    @staticmethod
    def evi(nir, red):
        '''
        Calculate evi Index
            Inputs: nir Band, red Band.
            Outputs: evi Index (Double or float)
        '''
        nomin = 2.5 * (nir-red)
        den_nomin = nir + 2.4 * red + 1
        evi = nomin / den_nomin
        evi[den_nomin == 0] = 0
        return evi

    @staticmethod
    def g_ndvi(nir, green):
        '''
        Calculate GNDVI Index
            Inputs: nir Band, green Band.
            Outputs: GNDVI Index (Double or float)
        '''
        return Base.index_v2(nir, green)

    @staticmethod
    def mcari(red_edge_5, red, green):
        '''
        Calculate mcari Index
            Inputs: red_edge_5 Band, red Band,green Band.
            Outputs: mcari Index (Double or float)
        '''
        nomin = (red_edge_5 - red) - 0.2 * (red_edge_5 - green)
        den_nomin = red_edge_5 / red
        mcari = nomin * den_nomin
        mcari[den_nomin == 0] = 0
        return mcari

    @staticmethod
    def mtci(nir, red_edge_5):
        '''
        Calculate MTCI Index
            Inputs: red_edge_5 Band, nir Band.
            Outputs: MTCI Index (Double or float)
        '''
        return Base.index_v2(nir, red_edge_5)

    @staticmethod
    def ndrei(nir, red_edge_5):
        '''
        Calculate NDREI Index
            Inputs: red_edge_5 Band, nir Band.
            Outputs: NDREI Index (Double or float)
        '''
        return Base.index_v2(nir, red_edge_5)

    @staticmethod
    def ndwi2(nir, swir1):
        '''
        Calculate NDWI2 Index
            Inputs: SWIR Band, nir Band.
            Outputs: NDWI2 Index (Double or float)
        '''
        return Base.index_v2(nir, swir1)

    @staticmethod
    def ngrdi(green, red):
        '''
        Calculate NGRDI Index
            Inputs: green Band, red Band.
            Outputs: NGRDI Index (Double or float)
        '''
        return Base.index_v2(green, red)

    @staticmethod
    def osavi(nir, red):
        '''
        Calculate OSAVI Index
            Inputs: nir Band, red Band.
            Outputs: OSAVI Index (Double or float)
        '''
        nomin = (1 + 0.16) * (nir - red)
        den_nomin = nir + red + 0.16
        osavi = nomin / den_nomin
        osavi[den_nomin == 0] = 0
        return osavi

    @staticmethod
    def reip(red, red_edge_7, red_edge_5):
        '''
        Calculate reip Index
            Inputs: red_edge_7 Band, red_edge_5 Band,red Band.
            Outputs: reip Index (Double or float)
        '''
        nomin = ((red + red_edge_7) / 2) - red_edge_5
        den_nomin = red - red_edge_5
        reip = 700 + 40 * (nomin / den_nomin)
        reip[den_nomin == 0] = 0
        return reip

    @staticmethod
    def rep_ndvi(nir, red, red_edge_5, red_edge_6):
        '''
        Calculate RepNDVI Index
            Inputs: red_edge_6 Band, red_edge_5 Band,red Band, nir Band.
            Outputs: RepNDVI Index (Double or float)
        '''
        nomin = nir - red
        den_nomin = nir + red
        ndvi = nomin / den_nomin
        ndvi[den_nomin == 0] = 0
        rep = red_edge_6 / red_edge_5
        rep[red_edge_5 == 0] = 0
        rep = np.sqrt(rep)
        rep_ndvi = ndvi * rep
        return rep_ndvi

    @staticmethod
    def s2_rep(red, red_edge_7, red_edge_5, red_edge_6):
        '''
        Calculate S2Rep Index
            Inputs: red Band, red_edge_7 Band, red_edge_5 Band,red_edge_6 Band.
            Outputs: S2Rep Index (Double or float)
        '''
        s2_rep = 705 + 35 * (0.5 * (red + red_edge_7)) - red_edge_5 / (
                 red_edge_6 - red_edge_5
        )
        s2_rep = s2_rep[s2_rep == 0] = 0
        return s2_rep

    @staticmethod
    def savi(nir, red):
        '''
        Calculate savi Index
            Inputs: red Band, nir Band.
            Outputs: savi Index (Double or float)
        '''
        nomin = 1.5 * (nir - red)
        den_nomin = nir + red + 0.5
        savi = nomin / den_nomin
        savi[den_nomin == 0] = 0
        return savi

    @staticmethod
    def tcari(red_edge_5, green, red):
        '''
        Calculate TCARI Index
            Inputs: red_edge_5 Band, green Band,red Band.
            Outputs: TCARI Index (Double or float)
        '''
        tcari = 3 * ((red_edge_5 - red) - 0.2 *
                     (red_edge_5 - green) *
                     (red_edge_5 / red))
        tcari[red == 0] = 0
        return tcari

    @staticmethod
    def tci(red_edge_5, green, red):
        '''
        Calculate tci Index
            Inputs: red Band, green Band, red_edge_5 Band.
            Outputs: tci Index (Double or float)
        '''
        tci = 1.2 * (red_edge_5 - green) - (
              1.5 * (red - green) * np.sqrt(red_edge_5 / red)
        )

        tci[red == 0] = 0
        return tci

    @staticmethod
    def tgi(red, green, blue):
        '''
        Calculate TGI Index
            Inputs: red Band, green Band, blue Band.
            Outputs: TGI Index (Double or float)
        '''
        tgi = (0.5)*((0.175) * (red - green) - (0.105) * (red - blue))
        return tgi

    @staticmethod
    def vari(blue, green, red):
        '''
        Calculate vari Index
            Inputs: red Band, blue Band, green Band.
            Outputs: vari Index (Double or float)
        '''
        nomin = green - red
        den_nomin = green + red - blue
        vari = nomin / den_nomin
        vari[den_nomin == 0] = 0
        return vari

    @staticmethod
    def diff_index(band1, band2):
        '''
        Calculate Difference Index
            Inputs: 2 Image Bands
            Outputs: Differenve Index (Double or float)
        '''
        return band1 - band2

    @staticmethod
    def normalized_index(band1, band2):
        '''
        Calculate Normalized Index
            Inputs: 2 Image Band.
            Outputs: NormalizedIndex (Double or float)
        '''
        return Base.index_v2(band1, band2)

    @staticmethod
    def ratio_index(nomin, denomin):
        '''
        Calculate Ratio Index
            Inputs: 2 Image band.
            Outputs: Ratio Index Index (Double or float)
        '''
        return Base.index_v1(nomin, denomin)

    @staticmethod
    def dry_biomass(bst_index, s, intercept):
        '''
        Calculate dry Biomass.
            Inputs: Index.
            Outputs: drybiomass (Double or float)
        '''
        return Base.index_v4(bst_index, s, intercept)

    @staticmethod
    def wet_biomass(bst_index, s, intercept):
        '''
        Calculate wetbiomass.
            Inputs:  Index
            Outputs: wetbiomass (Double or float)
        '''
        return Base.index_v4(bst_index, s, intercept)

    @staticmethod
    def lai(bst_index, s, intercept):
        '''
        Calculate LAI for Alfalfa Ghazvin
            Inputs: Index.
            Outputs: LAI (Double or float)
        '''
        return Base.index_v4(bst_index, s, intercept)
