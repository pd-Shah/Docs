
from matplotlib import pyplot as plt
from sklearn import datasets, linear_model
from pandas import DataFrame
import numpy as np
#load data set
diabetes=datasets.load_diabetes()
#print(diabetes.data.shape)
#print(diabetes.target.shape)

#diabetes_X = diabetes.data[:,2]
diabetes_X = diabetes.data[:,np.newaxis ,2]
#print(diabetes_X)

# Split the data into training/testing sets
diabetes_X_train = diabetes_X[:-20]
diabetes_X_test = diabetes_X[-20:]


diabetes_y=diabetes.target[:,np.newaxis]
# Split the targets into training/testing sets
diabetes_y_train = diabetes_y[:-20]
diabetes_y_test = diabetes_y[-20:]


# Create linear regression object
obj_reg=linear_model.LinearRegression()

obj_reg.fit(diabetes_X_train, diabetes_y_train)

perdic=obj_reg.predict(diabetes_X_test)


# The coefficients
print('Coefficients: \n', obj_reg.coef_)
print(obj_reg.intercept_)
# Plot outputs
plt.scatter(diabetes_X_test, diabetes_y_test,  color='blue')
plt.plot(diabetes_X_test, obj_reg.predict(diabetes_X_test), color='red',linewidth=1)
plt.xticks(())
plt.yticks(())
plt.show()
#print(obj_reg.score(diabetes_X_test, diabetes_y_test))
