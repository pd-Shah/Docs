from version_check import VersionCheck
import os
from osgeo import gdal

def foo():
    #crtl shit allt o -> commmand -> python2
    #VersionCheck()
    raster_file=gdal.Open('inputfiles/band2pp.tif')

    band=raster_file.GetRasterBand(1)
    y=raster_file.GetMetadata()
    raster_file.GetDescription()
    raster_file.GetFileList()
    raster_file.RasterCount
    raster_file.RasterXSize
    raster_file.RasterYSize
    raster_file.GetNoDataValue()
    raster_file.ReadAsArray()
    band.ComputeRasterMinMax()
    band.GetHistogram()
    print(type(y))
    print(y)



    '''
    Reading partial datasets

    band.ReadAsArray([xoff], [yoff], [win_xsize], [win_ysize], [buf_xsize],[buf_ysize], [buf_obj])
        xoff is the column to start reading at. The default value is 0.
        yoff is the row to start reading at. The default value is 0.
        win_xsize is the number of columns to read. The default is to read them all.
        win_ysize is the number of rows to read. The default is to read them all.
        buf_xsize is the number of columns in the output array. The default is to use the
        win_xsize value. Data will be resampled if this value is different than win_xsize .188
        buf_ysize is the number of rows in the output array. The default is to use the
        win_ysize value. Data will be resampled if this value is different than win_ysize .
        buf_obj is a NumPy array to put the data into instead of creating a new array.
        Data will be resampled, if needed, to
    '''
    data = band.ReadAsArray(1400, 6000, 6, 3).astype(float)

    '''
    transform

    ApplyGeoTransform this function converts image coordinates (offsets) to real-world coordinates.
    ApplyGeoTransform	(	double * 	padfGeoTransform,
    double 	dfPixel,
    double 	dfLine,
    double * 	pdfGeoX,
    double * 	pdfGeoY
    )

    Apply GeoTransform to x/y coordinate.

    Applies the following computation, converting a (pixel, line) coordinate into a georeferenced (geo_x, geo_y) location.

    *pdfGeoX = padfGeoTransform[0] + dfPixel * padfGeoTransform[1]

    dfLine * padfGeoTransform[2]; *pdfGeoY = padfGeoTransform[3] + dfPixel * padfGeoTransform[4]
    dfLine * padfGeoTransform[5];
    Parameters
    padfGeoTransform	Six coefficient GeoTransform to apply.
    dfPixel	Input pixel position.
    dfLine	Input line position.
    pdfGeoX	output location where geo_x (easting/longitude) location is placed.
    pdfGeoY	output location where geo_y (northing/latitude) location is placed.

    reverce :If youre using GDAL 2.x, then the InvGeoTransform function only returns one
    item: a geotransform if one could be calculated, or None if not. In this case, you need
    to make sure that the returned value isnt equal to None :
    gt = ds.GetGeoTransform()
    inv_gt = gdal.InvGeoTransform(gt)
    '''
    ds=gdal.Open('inputfiles/band2pp.tif')
    gt=ds.GetGeoTransform()
    inv_gt=gdal.InvGeoTransform(gt)
    offsets = gdal.ApplyGeoTransform(inv_gt, 465200, 5296000)
    xoff, yoff = map(int, offsets)
    value = band.ReadAsArray(xoff, yoff)[0,0]

    x, y = map(int, gdal.ApplyGeoTransform(inv_gt, 465200, 5296000))
    value = data[yoff, xoff]
