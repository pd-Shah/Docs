
import rasterio
import numpy as np
from sklearn.metrics import mean_absolute_error, r2_score


class Algorithm(object):

    @staticmethod
    def read_file(file_dir):
        '''
        to read raster file
        return numpy array
        '''
        assert type(file_dir) is str, "dir must be string"

        with rasterio.open(file_dir) as src:
            arr = src.read(1).astype(np.float)
        return arr

    @staticmethod
    def make_Xy_ready(X_objects, y):
        '''
        to make X and y from 3 numpy array and y
        return X_train, X_test, y_train, y_test
        '''

        from sklearn.cross_validation import train_test_split

        if len(X_objects) == 3:
            X_arr1, X_arr2, X_arr3 = X_objects
            assert type(X_arr1) is np.ndarray, 'arr1 must be numpy array'
            assert type(X_arr2) is np.ndarray, 'arr2 must be numpy array'
            assert type(X_arr3) is np.ndarray, 'arr3 must be numpy array'
            assert type(y) is np.ndarray, 'y must be numpy array'

            concate_array = np.concatenate(
                ([X_arr1], [X_arr2], [X_arr3]),
                axis=0
            )

        elif len(X_objects) == 4:
            X_arr1, X_arr2, X_arr3, X_arr4 = X_objects
            assert type(X_arr1) is np.ndarray, 'arr1 must be numpy array'
            assert type(X_arr2) is np.ndarray, 'arr2 must be numpy array'
            assert type(X_arr3) is np.ndarray, 'arr3 must be numpy array'
            assert type(X_arr4) is np.ndarray, 'arr4 must be numpy array'
            assert type(y) is np.ndarray, 'y must be numpy array'

            concate_array = np.concatenate(
                ([X_arr1], [X_arr2], [X_arr3], [X_arr4]),
                axis=0
            )

        elif len(X_objects) == 5:
            X_arr1, X_arr2, X_arr3, X_arr4, X_arr5 = X_objects
            assert type(X_arr1) is np.ndarray, 'arr1 must be numpy array'
            assert type(X_arr2) is np.ndarray, 'arr2 must be numpy array'
            assert type(X_arr3) is np.ndarray, 'arr3 must be numpy array'
            assert type(X_arr4) is np.ndarray, 'arr4 must be numpy array'
            assert type(X_arr5) is np.ndarray, 'arr5 must be numpy array'
            assert type(y) is np.ndarray, 'y must be numpy array'

            concate_array = np.concatenate(
                ([X_arr1], [X_arr2], [X_arr3], [X_arr4], [X_arr5]),
                axis=0
            )

        X = concate_array.transpose(1, 2, 0).reshape(-1,
                                                     concate_array.shape[0]
                                                     )
        y = y.flatten()

        X_train, X_test, y_train, y_test = train_test_split(X, y)

        return X_train, X_test, y_train, y_test

    @staticmethod
    def random_forest(X_train, X_test, y_train, y_test):
        '''
        to run random forest algorithm
        return score
        '''

        from sklearn.ensemble import RandomForestClassifier
        assert type(X_train) is np.ndarray, 'X_train must be numpy array'
        assert type(X_test) is np.ndarray, 'X_test must be numpy array'
        assert type(y_train) is np.ndarray, 'y_train must be numpy array'
        assert type(y_test) is np.ndarray, 'y_test must be numpy array'

        random_forest = RandomForestClassifier()

        random_forest.fit(X_train, y_train)

        predict_data = random_forest.predict(X_test)

        score = random_forest.score(X_test, y_test)
        mae = mean_absolute_error(y_test, predict_data)
        r2 = r2_score(y_test, predict_data)

        return {'score': score, 'mae': mae, 'r2': r2}

    @staticmethod
    def decesition_tree(X_train, X_test, y_train, y_test):
        '''
        to run decesition tree algorithm
        return score
        '''

        from sklearn.tree import DecisionTreeClassifier
        assert type(X_train) is np.ndarray, 'X_train must be numpy array'
        assert type(X_test) is np.ndarray, 'X_test must be numpy array'
        assert type(y_train) is np.ndarray, 'y_train must be numpy array'
        assert type(y_test) is np.ndarray, 'y_test must be numpy array'

        decesition_tree = DecisionTreeClassifier()

        decesition_tree.fit(X_train, y_train)

        predict_data = decesition_tree.predict(X_test)

        mae = mean_absolute_error(y_test, predict_data)
        r2 = r2_score(y_test, predict_data)
        score = decesition_tree.score(X_test, y_test)

        return {'score': score, 'mae': mae, 'r2': r2}

    @staticmethod
    def gussian_process_regresion(X_train, X_test, y_train, y_test):
        '''
        to run gusian process regresion algorithm
        return score
        '''

        from sklearn.gaussian_process import GaussianProcessRegressor
        assert type(X_train) is np.ndarray, 'X_train must be numpy array'
        assert type(X_test) is np.ndarray, 'X_test must be numpy array'
        assert type(y_train) is np.ndarray, 'y_train must be numpy array'
        assert type(y_test) is np.ndarray, 'y_test must be numpy array'

        gusian_process_regresion = GaussianProcessRegressor()

        gusian_process_regresion.fit(X_train[:10000], y_train[:10000])

        predict_data = gusian_process_regresion.predict(X_test)

        mae = mean_absolute_error(y_test, predict_data)
        r2 = r2_score(y_test, predict_data)
        score = gusian_process_regresion.score(X_test, y_test)

        return {'score': score, 'mae': mae, 'r2': r2}

    @staticmethod
    def svr(X_train, X_test, y_train, y_test):
        '''
        to run gusian process regresion algorithm
        return score
        '''

        from sklearn.svm import SVR
        assert type(X_train) is np.ndarray, 'X_train must be numpy array'
        assert type(X_test) is np.ndarray, 'X_test must be numpy array'
        assert type(y_train) is np.ndarray, 'y_train must be numpy array'
        assert type(y_test) is np.ndarray, 'y_test must be numpy array'

        svr = SVR()

        svr.fit(X_train[:10000], y_train[:10000])

        predict_data = svr.predict(X_test)

        mae = mean_absolute_error(y_test, predict_data)
        r2 = r2_score(y_test, predict_data)
        score = svr.score(X_test, y_test)

        return {'score': score, 'mae': mae, 'r2': r2}
