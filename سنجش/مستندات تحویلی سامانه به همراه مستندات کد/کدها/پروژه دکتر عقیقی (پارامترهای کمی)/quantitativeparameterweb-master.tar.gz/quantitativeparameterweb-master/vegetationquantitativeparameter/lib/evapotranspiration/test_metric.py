#standard libs import
import unittest
import numpy as npy
from numpy.testing import assert_allclose as np_assert_allclose


TEST_DIR="src/test/"

def read_csv_as_numpy(file_name, sub_dir, root_dir=TEST_DIR):
    file_dir=root_dir+sub_dir
    csv = npy.genfromtxt (file_dir+file_name, delimiter=",")
    return csv


class TestMain(unittest.TestCase):
    # def test_Emissiv_1(self):
    #     # file directory
    #     sub_dir='Emissiv_1/'
    #     test_arr= read_csv_as_numpy('Emissiv_1_107.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('p_emissivity1.csv', sub_dir)
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-3)
    # #
    # #
    # def test_NDVI(self):
    #     #file directory
    #     sub_dir='NDVI_95/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('NDVI_95.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('P_NDVI1 .csv', sub_dir)
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-3)
    #
    # def test_NDVI6(self):
    #     #file directory
    #     sub_dir='NDVI6_100/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('NDVI6_100.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('P_NDVI16_101.csv', sub_dir)
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)
    # #
    # #
    # def test_NDVI7(self):
    #     #file directory
    #     sub_dir='NDVI7_101/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('NDVI7_101.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('P_NDVI17_101.csv', sub_dir)
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    # def  test_vegetationfraction(self):
    #     sub_dir='vegetablefraction/'
    #
    #     #read test file
    #     test_arr=read_csv_as_numpy('vegetationfraction_126.csv',sub_dir)
    #
    #     #read pyhon output
    #     py_arr=read_csv_as_numpy('p_vegetationfraction.csv',sub_dir)
    #     #testing,rtol=1e-4->4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)
    #
    # def test_cavity10(self):
    #     #file directory
    #     sub_dir='cavity10-135/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('Cavity10_129.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('p_Cavity10.csv', sub_dir)
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    # def test_cavity11(self):
    #
    #     #file directory
    #     sub_dir='cavity11-135/'
    #
    #     #read test file
    #     test_arr= read_csv_as_numpy('Cavity11_130.csv', sub_dir)
    #
    #     #read python output
    #     py_arr= read_csv_as_numpy('p_Cavity11.csv', sub_dir)
    #
    #     #testing, rtol=1e-4 -> 4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    #  def test_Emissiv_1(self):
    #       #file directory
    #       sub_dir='Emissiv_1/'
    #       #read test file
    #       test_arr=read_csv_as_numpy('Emissiv_1_107.csv',sub_dir)
    #       #read pyhon output
    #       py_arr=read_csv_as_numpy('p_emissivity1.csv',sub_dir)
    #       #testing,rtol=1e-4->4 floating point
    #       np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    # def test_emissiv210(self):
    #     #file directory
    #     sub_dir='emissive210-110/'
    #
    #     #read test file
    #     test_arr=read_csv_as_numpy('Emissiv_210_110.csv',sub_dir)
    #
    #     #read pyhon output
    #     py_arr=read_csv_as_numpy('p_emissivity210.csv',sub_dir)
    #     #testing,rtol=1e-4->4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-1)

    # def test_emissiv211(self):
    #     #file directory
    #     sub_dir='emissiv211-110/'
    #
    #     #read test file
    #     test_arr=read_csv_as_numpy('Emissiv_211_110.csv',sub_dir)
    #
    #     #read pyhon output
    #     py_arr=read_csv_as_numpy('emissivity211.csv',sub_dir)
    #
    #     # npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #     # npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-4)], delimiter=',')
    #
    #     #testing,rtol=1e-4->4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)



    # #
    #  def test_emissive10_loop(self):
    #       #file directory
    #       sub_dir='emissivity10_loop/'
    #       #read test file
    #       test_arr=read_csv_as_numpy('emissivity10_loop135.csv',sub_dir)
    #       #read pyhon output
    #       py_arr=read_csv_as_numpy('p_emissivity10_loop.csv',sub_dir)
    #       #testing,rtol=1e-4->4 floating point
    #       np_assert_allclose(py_arr, test_arr, rtol=1e-1)

    #   def test_emissive11_loop(self):
    #        #file directory
    #        sub_dir='emissivity11_loop/'
    #        #read test file
    #        test_arr=read_csv_as_numpy('emissivity11_loop135.csv',sub_dir)
    #        #read pyhon output
    #        py_arr=read_csv_as_numpy('p_emissivity11.csv',sub_dir)
      #
    #     #    npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #     #    npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #        #
    #        #testing,rtol=1e-4->4 floating point
    #        np_assert_allclose(py_arr, test_arr, rtol=1e-1)

    # def  test_albedo(self):
    #     sub_dir='albedo/'
    #
    #     #read test file
    #     test_arr=read_csv_as_numpy('albedo_251.csv',sub_dir)
    #
    #     #read pyhon output
    #     py_arr=read_csv_as_numpy('P_albedo.csv',sub_dir)
    #     #testing,rtol=1e-4->4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-2)
    # #
    #   def test_lstcase(self):
    #       #file directory
    #       sub_dir='lstcase/'
    #       #read test file
    #       test_arr=read_csv_as_numpy('LST_case159.csv',sub_dir)
    #       #read pyhon output
    #       py_arr=read_csv_as_numpy('p_lstcase.csv',sub_dir)
    #       #testing,rtol=1e-4->4 floating point
    #       np_assert_allclose(py_arr, test_arr, rtol=1e-2)

      #
    #   def test_emissivitycase(self):
    #       #file directory
    #       sub_dir='emissivitycase/'
    #       #read test file
    #       test_arr=read_csv_as_numpy('Emissivity_case159.csv',sub_dir)
    #       #read pyhon output
    #       py_arr=read_csv_as_numpy('Emissivity.csv',sub_dir)
      #
    #       npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #       npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
      #
    #       #testing,rtol=1e-4->4 floating point
    #       np_assert_allclose(py_arr, test_arr, rtol=1e-2)

    #   def test_transmissivity(self):
    #       #file directory
    #       sub_dir='transmissivity/'
    #       #read test file
    #       test_arr=read_csv_as_numpy('AtmosphericTransmissivity_247.csv',sub_dir)
    #       #read pyhon output
    #       py_arr=read_csv_as_numpy('p_Transmissivity.csv',sub_dir)
    #
    #       npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #       npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #
    #       #testing,rtol=1e-4->4 floating point
    #       np_assert_allclose(py_arr, test_arr, rtol=1e-2)

    #
    # def  test_albedo(self):
    #     sub_dir='albedo/'
    #
    #     #read test file
    #     test_arr=read_csv_as_numpy('albedo_251.csv',sub_dir)
    #     #read pyhon output
    #     py_arr=read_csv_as_numpy('P_albedo.csv',sub_dir)
    #     #testing,rtol=1e-4->4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-2)

    # def  test_LongWaveOut(self):
    #     sub_dir='longwaveout/'
    #
    #     #read test file
    #     test_arr=read_csv_as_numpy('LongWaveOutward_256.csv',sub_dir)
    #
    #     #read pyhon output
    #     py_arr=read_csv_as_numpy('p_LongWaveOut.csv',sub_dir)
    #     #testing,rtol=1e-4->4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-4)
    # def  test_Lstcase0(self):
    #     sub_dir='lstcase0/'
    #
    #     #read test file
    #     test_arr=read_csv_as_numpy('LST_case0.csv',sub_dir)
    #
    #     #read pyhon output
    #     py_arr=read_csv_as_numpy('p_LSTcase0.csv',sub_dir)
    #     #testing,rtol=1e-4->4 floating point
    #     np_assert_allclose(py_arr, test_arr, rtol=1e-2)

    # def  test_radianceband10(self):
    #         sub_dir='p_radiance.band10/'
    # #
    #         #read test file
    #         test_arr=read_csv_as_numpy('Radiance.band10.csv',sub_dir)
    #         #read pyhon output
    #         py_arr=read_csv_as_numpy('p_radiance.band10',sub_dir)
    #         #testing,rtol=1e-4->4 floating point
    #         np_assert_allclose(py_arr, test_arr, rtol=1e-2)


    #
    # def  test_LongWaveInward(self):
    #         sub_dir='LongWaveInward/'
    #
    #         #read test file
    #         test_arr=read_csv_as_numpy('LongWaveInward_273.csv',sub_dir)
    #
    #         #read pyhon output
    #         py_arr=read_csv_as_numpy('LongWaveInward_this.csv',sub_dir)
    #         # print(test_arr.shape)
    #         # print(py_arr.shape)
    #         #testing,rtol=1e-4->4 floating point
    #         np_assert_allclose(py_arr, test_arr, rtol=1e-1)
    #
    # def  test_zom(self):
    #         sub_dir='zom/'
    #         #read test file
    #         test_arr=read_csv_as_numpy('Zom_309.csv',sub_dir)
    #         #read pyhon output
    #         py_arr=read_csv_as_numpy('P_Zom2.csv',sub_dir)
    #         #testing,rtol=1e-4->4 floating point
    #         np_assert_allclose(py_arr, test_arr, rtol=1e-4)

    # def  test_SHORTWAVE(self):
    #         sub_dir='shortwave/'
    #         #read test file
    #         test_arr=read_csv_as_numpy('ShortWaveRadiation_277.csv',sub_dir)
    #         #read pyhon output
    #         py_arr=read_csv_as_numpy('p_ShortWaveRadiation.csv',sub_dir)
    #         #testing,rtol=1e-4->4 floating point
    #         npy.savetxt('matlab.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #         npy.savetxt('python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #         np_assert_allclose(py_arr, test_arr, rtol=1e-1)

    #
    # def  test_rn(self):
    #         sub_dir='rn/'
    #         #read test file
    #         test_arr=read_csv_as_numpy('Rn_282.csv',sub_dir)
    #         #read pyhon output
    #         py_arr=read_csv_as_numpy('Rn.csv',sub_dir)
    #         # npy.savetxt('sara-mat.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #         # npy.savetxt('sara-python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #         #testing,rtol=1e-4->4 floating point
    #         np_assert_allclose(py_arr, test_arr, rtol=1e-3)


    # def  test_groundheat(self):
    #         sub_dir='ground-heat/'
    #         #read test file
    #         test_arr=read_csv_as_numpy('GroundHeat_288.csv',sub_dir)
    #         #read pyhon output
    #         py_arr=read_csv_as_numpy('p_GroundHeat.csv',sub_dir)
    #         # npy.savetxt('sara-mat.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #         # npy.savetxt('sara-python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
    #         #testing,rtol=1e-4->4 floating point
    #         np_assert_allclose(py_arr, test_arr, rtol=1e-3)

    def  test_SAVI(self):
            sub_dir='savi/'
            #read test file
            test_arr=read_csv_as_numpy('SAVI_297.csv',sub_dir)
            #read pyhon output
            py_arr=read_csv_as_numpy('f_SAVI.csv',sub_dir)
            # npy.savetxt('sara-mat.csv', test_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
            # npy.savetxt('sara-python.csv', py_arr[~npy.isclose(test_arr, py_arr, rtol=1e-2)], delimiter=',')
            #testing,rtol=1e-4->4 floating point
            np_assert_allclose(py_arr, test_arr, rtol=1e-3)

if __name__=="__main__":
    unittest.main()
