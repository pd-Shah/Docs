from django.conf.urls import url
from rest_framework_swagger.views import get_swagger_view

from . import views

swagger = get_swagger_view(title='Public API')

urlpatterns = [
        url(r'^region/$',
            view=views.RegionListApiView.as_view(),
            name='region_list_api'),

        url(r'^region/(?P<pk>\d+)/$',
            view=views.RegionRetrieveAPIView.as_view(),
            name='region_detail_api'),

        url(r'^evapotranspiration/$',
            view=views.EvapotranspirationListApiView.as_view(),
            name='evapotranspiration_list_api'),

        url(r'^evapotranspiration/(?P<pk>[0-9A-Fa-f-]+)/$',
            view=views.EvapotranspirationRetrieveAPIView.as_view(),
            name='evapotranspiration_detail_api'),

        url(r'^evapotranspiration/(?P<pk>[0-9A-Fa-f-]+)/run/$',
            view=views.EvapotranspirationRetrieveAPIRun.as_view(),
            name='evapotranspiration_retrieve_api_run'),

        url(r'^biomasslai/$',
            view=views.BiomassLaiListApiView.as_view(),
            name='biomasslai_list_api'),

        url(r'^biomasslai/(?P<pk>[0-9A-Fa-f-]+)/$',
            view=views.BiomassLaiRetrieveAPIView.as_view(),
            name='biomasslai_detail_api'),

        url(r'^biomasslai/(?P<pk>[0-9A-Fa-f-]+)/run/$',
            view=views.BiomassLaiRetrieveAPIRun.as_view(),
            name='biomasslai_retrieve_api_run'),

        url(r'^swagger/$', view=swagger, name='swagger'),
]
