from rest_framework import generics

from vegetationquantitativeparameter import models
from . import serializers

from ..lib import engine


class RegionListApiView(generics.ListAPIView):
    serializer_class = serializers.RegionSerializer

    def get_queryset(self, ):
        return models.Region.objects.all()


class RegionRetrieveAPIView(generics.RetrieveAPIView):
    serializer_class = serializers.RegionSerializer

    def get_queryset(self, ):
        return models.Region.objects.all()


class EvapotranspirationListApiView(generics.ListAPIView):
    serializer_class = serializers.EvapotranspirationSrializer

    def get_queryset(self, ):
        return models.Evapotranspiration.objects.all()


class EvapotranspirationRetrieveAPIView(generics.RetrieveAPIView):
    serializer_class = serializers.EvapotranspirationSrializer

    def get_queryset(self, ):
        return models.Evapotranspiration.objects.all()


class EvapotranspirationRetrieveAPIRun(generics.RetrieveAPIView):
    serializer_class = serializers.EvapotranspirationSrializer

    def get_queryset(self, ):
        engine.evapotranspiration_connect_engine(self.kwargs['pk'])
        return models.Evapotranspiration.objects.all()


class BiomassLaiListApiView(generics.ListAPIView):
    serializer_class = serializers.BiomassLaiSerializer

    def get_queryset(self, ):
        return models.BiomassLai.objects.all()


class BiomassLaiRetrieveAPIView(generics.RetrieveAPIView):
    serializer_class = serializers.BiomassLaiSerializer

    def get_queryset(self, ):
        return models.BiomassLai.objects.all()


class BiomassLaiRetrieveAPIRun(generics.RetrieveAPIView):
    serializer_class = serializers.BiomassLaiSerializer

    def get_queryset(self, ):
        engine.biomass_lai_connect_engine(self.kwargs['pk'])
        return models.BiomassLai.objects.all()
