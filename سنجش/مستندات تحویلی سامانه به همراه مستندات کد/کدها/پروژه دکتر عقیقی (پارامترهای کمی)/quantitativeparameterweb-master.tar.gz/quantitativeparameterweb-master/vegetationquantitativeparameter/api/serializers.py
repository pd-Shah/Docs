from rest_framework import serializers
from vegetationquantitativeparameter import models


class RegionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Region
        fields = ['id', 'name', 'last_modified_date']


class EvapotranspirationSrializer(serializers.ModelSerializer):
    class Meta:
        model = models.Evapotranspiration
        fields = ['id', 'region_name', 'date', 'result_metric', 'result_sebal']


class BiomassLaiSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.BiomassLai
        fields = ['id', 'region_name', 'date', 'alfalfa_dry_biomass_result',
                  'alfalfa_lai_result', 'alfalfa_wet_biomass_result',
                  'maize_dry_biomass_result', 'maize_lai_result',
                  'maize_wet_biomass_result', ]
