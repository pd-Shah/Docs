from django.conf.urls import url, include
from . import views

app_name = 'vegetationquantitativeparameter'


urlpatterns = [
    url(r'^api/',
        include('vegetationquantitativeparameter.api.urls'),
        name='vegetationquantitativeparameter_api'),

    url(r'^home/$',
         views.home,
         name='home'),


    url(r'^ghazvin/$',
         views.ghazvin,
         name='ghazvin'),

    url(r'^moghan/$',
         views.moghan,
         name='moghan'),

    url(r'regions/$',
         views.RegionListView.as_view(),
         name='region-list'),

    url(r'region/(?P<pk>\d+)/$',
         views.RegionDetailView.as_view(),
         name='region-detail'),

    url(r'lai-biomass/results/$',
         views.BiomassLaiListView.as_view(),
         name='laibiomass-results'),

    url(r'lai-biomass/result/(?P<pk>[0-9A-Fa-f-]+)/$',
         views.BiomassLaiDetailView.as_view(),
         name='laibiomass-result-detailview'),

    url(r'evapotranspiration/results/$',
         views.ETListView.as_view(),
         name='et-results'),

    url(r'evapotranspiration/result/(?P<pk>[0-9A-Fa-f-]+)/$',
         views.ETDetailView.as_view(),
         name='et-result-detailview'),
    url(r'^$', view=views.land, name="landing_page" )

]
