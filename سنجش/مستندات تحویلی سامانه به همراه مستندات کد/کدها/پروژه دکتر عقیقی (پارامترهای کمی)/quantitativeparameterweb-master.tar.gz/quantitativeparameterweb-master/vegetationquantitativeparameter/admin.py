from django.contrib import admin
from . import models


@admin.register(models.Region)
class RegionAdmin(admin.ModelAdmin):
    # fieldsets = [
    #     ("Region Information",{'fields': ['name', ]}),
    # ]
    list_filter = ['name', "last_modified_date"]
    list_display = ('name', 'last_modified_date', 'published_recently')


@admin.register(models.Evapotranspiration)
class EvapotranspirationAdmin(admin.ModelAdmin):
    list_filter = ('region', 'date')
    list_display = ('region', 'date')


@admin.register(models.BiomassLai)
class BiomassLaiAdmin(admin.ModelAdmin):
    """docstring for BiomassLaiAdmin."""
    list_filter = ('region', 'date')
    list_display = ('region', 'date')
