import datetime
import uuid

from django.db import models
from django.utils import timezone
from django.conf import settings
from django.contrib.postgres.fields import JSONField


def regions_upload_dir(self, filename):
    return "VegetationQuantitativeParameterApp/Regions/{0}/{1}".format(
        self.name, filename
    )


def analyze_upload_dir(self, filename):
    return 'VegetationQuantitativeParameterApp/Regions/{0}/Analyzes/{1}/{2}'.format(
                        self.name, self.id, filename
    )


def input_files_upload_dir(self, filename):
    return 'VegetationQuantitativeParameterApp/Regions/{0}/Analyzes/{1}/inputs/{2}'.format(
                        self.region.name, self.id, filename
    )


class Region(models.Model):
    name = models.CharField(
                            max_length=300,
                            help_text="Set the region name.",
                            unique=True
    )

    last_modified_date = models.DateTimeField(auto_now=True)

    def published_recently(self):
        return self.last_modified_date >= (
                                timezone.now() - datetime.timedelta(days=7)
        )

    published_recently.admin_order_field = 'last_modified_date'
    published_recently.boolean = True
    published_recently.short_description = 'Published recently?'

    def __str__(self):
        return str(self.name)


class Evapotranspiration(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    region = models.ForeignKey(Region, on_delete=models.CASCADE)
    date = models.DateField()

    root = models.CharField(max_length=500,
                            default=str(settings.MEDIA_ROOT + '/'),
                            editable=False)

    ground_data = models.FileField(upload_to=input_files_upload_dir,
                                   help_text="Select grounddata.xlsx.",
                                   max_length=300)

    band2 = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select band file(.tif).",
                             max_length=300)

    band3 = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select band file(.tif).",
                             max_length=300)

    band4 = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select band file(.tif).",
                             max_length=300)

    band5 = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select band file(.tif).",
                             max_length=300)

    band6 = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select band file(.tif).",
                             max_length=300)

    band7 = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select band file(.tif).",
                             max_length=300)

    band10 = models.FileField(upload_to=input_files_upload_dir,
                              help_text="Select band file(.tif).",
                              max_length=300)

    band11 = models.FileField(upload_to=input_files_upload_dir,
                              help_text="Select band file(.tif).",
                              max_length=300)

    meta = models.FileField(upload_to=input_files_upload_dir,
                            help_text="Select meta file(.txt).",
                            max_length=300)

    fmask = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select fmask file(.tif).",
                             max_length=300)

    dem = models.FileField(upload_to=input_files_upload_dir,
                           help_text="Select dem file(.tif).",
                           max_length=300)

    land_cover = models.FileField(upload_to=input_files_upload_dir,
                                  help_text="Select land cover file(.tif).",
                                  max_length=300)

    slope = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select slope file(.csv).",
                             max_length=300)

    aspect = models.FileField(upload_to=input_files_upload_dir,
                              help_text="Select aspect file(.csv).",
                              max_length=300)

    result_metric = models.FileField(upload_to=analyze_upload_dir,
                                     help_text="Select the result file(.tif).",
                                     blank=True,
                                     null=True,
                                     max_length=300)

    result_sebal = models.FileField(upload_to=analyze_upload_dir,
                                    help_text="Select the result file(.tif).",
                                    blank=True,
                                    null=True,
                                    max_length=300)

    def __str__(self):
        return str(self.id)

    def region_name(self, ):
        return str(self.region.name)

    def get_result_metric(self, ):
        return str(settings.MEDIA_URL + '/' +
                   str(self.result_metric))

    def get_result_sebal(self, ):
        return str(settings.MEDIA_URL + '/' +
                   str(self.result_sebal))


class BiomassLai(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    region = models.ForeignKey(Region, on_delete=models.CASCADE)
    date = models.DateField()

    blue = models.FileField(upload_to=input_files_upload_dir,
                            help_text="Select Blue file(.tif).",
                            max_length=300)

    green = models.FileField(upload_to=input_files_upload_dir,
                             help_text="Select Green file(.tif).",
                             max_length=300)

    narrow_nir = models.FileField(upload_to=input_files_upload_dir,
                                  help_text="Select NarrowNIR file(.tif).",
                                  max_length=300)

    nir = models.FileField(upload_to=input_files_upload_dir,
                           help_text="Select NIR file(.tif).",
                           max_length=300)

    red = models.FileField(upload_to=input_files_upload_dir,
                           help_text="Select Red file(.tif).",
                           max_length=300)

    red_edge_5 = models.FileField(upload_to=input_files_upload_dir,
                                  help_text="Select Rededge5 file(.tif).",
                                  max_length=300)

    red_edge_6 = models.FileField(upload_to=input_files_upload_dir,
                                  help_text="Select Rededge6 file(.tif).",
                                  max_length=300)

    red_edge_7 = models.FileField(upload_to=input_files_upload_dir,
                                  help_text="Select Rededge7 file(.tif).",
                                  max_length=300)

    swir_1 = models.FileField(upload_to=input_files_upload_dir,
                              help_text="Select SWIR_1 file(.tif).",
                              max_length=300)

    swir_2 = models.FileField(upload_to=input_files_upload_dir,
                              help_text="Select SWIR_2 file(.tif).",
                              max_length=300)

    alfalfa_dry = JSONField(default={
                                   1: [],
                                   2: [],
                                   3: [],
    })

    alfalfa_lai = JSONField(default={
                                   1: [],
                                   2: [],
                                   3: [],
    })

    alfalfa_wet = JSONField(default={
                                   1: [],
                                   2: [],
                                   3: [],
    })

    maize_dry = JSONField(default={
                                   1: [],
                                   2: [],
                                   3: [],
    })

    maize_lai = JSONField(default={
                                   1: [],
                                   2: [],
                                   3: [],
    })

    maize_wet = JSONField(default={
                                   1: [],
                                   2: [],
                                   3: [],
    })

    machinlearning_score = JSONField(null=True, blank=True)

    alfalfa_dry_biomass_result = models.FileField(
                                    upload_to=analyze_upload_dir,
                                    help_text="nothing to do!",
                                    blank=True,
                                    null=True,
                                    max_length=300
    )

    alfalfa_lai_result = models.FileField(
                                    upload_to=analyze_upload_dir,
                                    help_text="nothing to do!",
                                    blank=True,
                                    null=True,
                                    max_length=300
    )

    alfalfa_wet_biomass_result = models.FileField(
                                    upload_to=analyze_upload_dir,
                                    help_text="nothing to do!",
                                    blank=True,
                                    null=True,
                                    max_length=300
    )

    maize_dry_biomass_result = models.FileField(
                                    upload_to=analyze_upload_dir,
                                    help_text="nothing to do!",
                                    blank=True,
                                    null=True,
                                    max_length=300
    )

    maize_lai_result = models.FileField(
                                    upload_to=analyze_upload_dir,
                                    help_text="nothing to do!",
                                    blank=True,
                                    null=True,
                                    max_length=300
    )

    maize_wet_biomass_result = models.FileField(
                                    upload_to=analyze_upload_dir,
                                    help_text="nothing to do!",
                                    blank=True,
                                    null=True,
                                    max_length=300
    )

    def region_name(self, ):
        return str(self.region.name)

    def get_blue_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.blue))

    def get_green_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.green))

    def get_narrow_nir_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.narrow_nir))

    def get_nir_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.nir))

    def get_red_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.red))

    def get_red_edge_5_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.red_edge_5))

    def get_red_edge_6_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.red_edge_6))

    def get_red_edge_7_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.red_edge_7))

    def get_swir_1_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.swir_1))

    def get_swir_2_path(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.swir_2))

    def get_alfalfa_dry_biomass_result(self, ):
        return str(settings.MEDIA_URL + '/' +
                   str(self.alfalfa_dry_biomass_result))

    def get_alfalfa_lai_result(self, ):
        return str(settings.MEDIA_URL + '/' +
                   str(self.alfalfa_lai_result))

    def get_alfalfa_wet_biomass_result(self, ):
        return str(settings.MEDIA_URL + '/' +
                   str(self.alfalfa_wet_biomass_result))

    def get_maize_dry_biomass_result(self, ):
        return str(settings.MEDIA_URL + '/' +
                   str(self.maize_dry_biomass_result))

    def get_maize_lai_result(self, ):
        return str(settings.MEDIA_URL + '/' +
                   str(self.maize_lai_result))

    def get_maize_wet_biomass_result(self, ):
        return str(settings.MEDIA_URL + '/' +
                   str(self.maize_wet_biomass_result))

    def get_alfalfa_dry_biomass_result_media(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.alfalfa_dry_biomass_result))

    def get_alfalfa_lai_result_media(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.alfalfa_lai_result))

    def get_alfalfa_wet_biomass_result_media(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.alfalfa_wet_biomass_result))

    def get_maize_dry_biomass_result_media(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.maize_dry_biomass_result))

    def get_maize_lai_result_media(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.maize_lai_result))

    def get_maize_wet_biomass_result_media(self, ):
        return str(settings.MEDIA_ROOT + '/' +
                   str(self.maize_wet_biomass_result))
