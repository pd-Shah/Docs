remote sensing library

pure python
