from rest_framework import generics

from fusariom import models
from . import serializers

# from vegetationdiseases.lib import engine


class RegionListApiView(generics.ListAPIView):
    serializer_class = serializers.RegionListApiView

    def get_queryset(self, ):
        return models.region.objects.all()


# class RegionRetrieveAPIView(generics.RetrieveAPIView):
#     serializer_class = serializers.region
#
#     def get_queryset(self, ):
#         return models.region.objects.all()


# class FusariumListApiView(generics.ListAPIView):
#     serializer_class = serializers.FusariumSerializer
#
#     def get_queryset(self, ):
#         return models.Fusarium.objects.all()
#
#
# class FusariumRetrieveAPIView(generics.RetrieveAPIView):
#     serializer_class = serializers.FusariumSerializer
#
#     def get_queryset(self, ):
#         return models.Fusarium.objects.all()
