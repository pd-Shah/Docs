from django.conf.urls import url
from rest_framework_swagger.views import get_swagger_view

from . import views

swagger = get_swagger_view(title='Public API')

urlpatterns = [

    url(r'^region/$',
        view=views.RegionListApiView.as_view(),
        name='region_list_api'),
    #
    # url(r'^region/(?P<pk>\d+)/$',
    #     view=views.RegionRetrieveAPIView.as_view(),
    #     name='region_detail_api'),
    #
    # url(r'^fusarium/$',
    #     view=views.FusariumListApiView.as_view(),
    #     name='fusarium_list_api'),
    #
    # url(r'^fusarium/(?P<pk>[0-9A-Fa-f-]+)/$',
    #     view=views.FusariumRetrieveAPIView.as_view(),
    #     name='fusarium_detail_api'),

    url(r'^swagger/$', view=swagger, name='swagger'),
]
