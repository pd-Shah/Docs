from rest_framework import serializers
from fusariom import models


class RegionListApiView(serializers.ModelSerializer):
    class Meta:
        model = models.region
        fields = ['regionname', 'choice', 'year', 'data','lat_long_station']
