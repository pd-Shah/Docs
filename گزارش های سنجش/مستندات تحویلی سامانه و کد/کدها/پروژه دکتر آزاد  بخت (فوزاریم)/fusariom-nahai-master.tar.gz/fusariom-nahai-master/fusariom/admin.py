from django.contrib import admin
from .models import region



class regionAdmin(admin.ModelAdmin):
    list_display=['regionname', 'year']
admin.site.register(region,regionAdmin)


# Register your models here.
