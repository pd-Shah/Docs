from django.conf.urls import url, include
from . import views

app_name='fusariom'

urlpatterns = [
    url(r'^$' , views.index, name='index'),
    url(r'^api/', include("fusariom.api.urls"), name='fusariom_api'),
]
