import numpy as np


def prediction_function(data, c1, c3, c4, c5, c6, RH1, RH2, RH3, RH4, RN1, RN2,
                        TMIN1, TMIN2, TMIN3, TMIN4, TMAX1, TMAX2, TMAX3, TMAX4,
                        DIF5, DIF6, need_day_number):
    '''
    this function is prediction model for Fusarium Head Blight
            input:
            path:input path for excel file(input file)
            c1,c1,c3,c4,c5,c6,RH1,RH2,RH3,RH4,RN1,RN2,TMIN1,TMIN2,TMIN3,TMIN4,TMAX1,TMAX2,TMAX3,TMAX4,DIF5,DIF6:constraint coefficient(integer)

            sheet:sheet number (in each sheet data of every station saved),
            output:
            result_1: matrix (double) dimention:(1*sheet)
    '''

    result_1=np.empty(shape=[0,1])
# c1
    for i in range(need_day_number):
        condition_num_1=0
         # for every day condition calculated from starting date until starting+14
        for j in range(i,i+15):
            if np.logical_and(np.logical_and(data[i][1]>TMIN1,data[i][2]<TMAX1),data[i][3]>RH1).all():
                # condition result for C1
                condition_num_1=condition_num_1+1
            else:
                j=j+1
# c3
        condition_num_3=0
        for j in range(i,i+15):
            if np.logical_and(data[i][4]>RN1,data[i][3]>RH3).all():
                condition_num_3=condition_num_3+1
        else:
            j=j+1
# c4
        condition_num_4=0
        temp=np.empty(shape=[0,1])
        for j in range(i,i+15):

            if np.logical_and(np.logical_and(data[i][3]>RH4,data[i][1]>=TMIN2),data[i][2]<=TMAX2):
                temp=np.append(temp,[[1]],axis=0)
            else:
                temp=np.append(temp, [[0]],axis=0)
 # find consequent days that this conditon is true.
        day=0

        for i in range(temp.shape[0]-1):
            a1=temp[i]
            a2=temp[i+1]
            if a1==1 and a2==1:
                day=day+1
            else:
                i+i+1
# c5
        condition_num_5=0
        for j in range(i,i+15):
            if np.logical_and(np.logical_and(np.logical_and(np.logical_and(data[i][4]>RN2,data[i][1]>TMIN3),data[i][2]<TMAX3),data[i][2]>20),(data[i][2]-data[i][1])<DIF5).all():
                condition_num_5=condition_num_5+1
            else:
                j=j+1
# c6
        condition_num_6=0
        t=np.empty(shape=[0,1])
        for j in range(i,i+15):
            if np.logical_and(np.logical_and(data[i][1] > TMIN4, data[i][2] < TMAX4), data[i][2] > 20).all():
                t=np.append(t, [[data[i][1]-DIF6]],axis=0)


            else:
                j=j+1
        condition_num_6=np.sum(t)
        #calculate  result
        if condition_num_1<5:
            # R1 is integer
            R1=c1*(1/5)*condition_num_1
        else:
            R1=c1
        if condition_num_3<5:
            R3=c3*(1/5)*condition_num_3
        else:
            R3=c3

        if day<5:
            R4=c4*(1/5)*day
        else:
            R4=c4
        if condition_num_5<5:
            R5=c5*(1/5)*condition_num_5
        else:
            R5=c5
        if condition_num_6<25:
            R6=c6*(1/25)*condition_num_6
            R6=c6+R1+R3+R4+R5+R6
            #result_1 is  main output
        result_1=np.append(result_1,R1+R3+R4+R5)
    return result_1
