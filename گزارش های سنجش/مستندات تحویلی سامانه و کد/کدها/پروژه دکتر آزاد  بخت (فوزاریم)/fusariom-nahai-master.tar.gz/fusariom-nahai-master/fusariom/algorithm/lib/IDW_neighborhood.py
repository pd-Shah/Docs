import math
import numpy as np
def IDW_neighbourhood(D,vint,vcc, wV,V,vc,e,r1,j,i):
    # this a kind of interpolation method
    D=D.tolist()
    b=sorted(D)
    I=[]
    for k in b:
        I.append(D.index(k))
    D=np.array(D)
    # extract vc value for D
    vcc=vc[I]
    V=vcc[:r1]/(D[:r1]**math.e)
    wV=1/D[:r1]*math.e
    V=np.sum(V)/np.sum(wV)
    vint[j,i]=V
    return vint
