import numpy as np
from .lib.prediction_function import prediction_function
from .lib.interpolation import interpolation
from .lib.api import get_data
from matplotlib import pyplot as plt

#
def main(c1,
         c3,
         c4,
         c5,
         c6,
         time1,
         st1,
         RH1,
         RH2,
         RH3,
         RH4,
         RN1,
         RN2,
         TMIN1,
         TMAX1,
         TMIN2,
         TMAX2,
         TMIN3,
         TMAX3,
         TMIN4,
         TMAX4,
         DIF5,
         DIF6,
         year,
         day,
         a,
         b,
         data,
         xy,
         need_day_number=16,):
    day=int(day)
    year=int(year)
    # station data
    data=np.array(data)
    # latlong for every station
    xy=np.array(xy)
    result = np.empty(shape=[0,need_day_number])
    print("prediction starts...")
    for i in data:
        temp = prediction_function(data=i, c1=c1, c3=c3, c4=c4, c5=c5,
                                   c6=c6, RH1=RH1, RH2=RH2, RH3=RH3, RH4=RH4,
                                   RN1=RN1, RN2=RN2, TMIN1=TMIN1, TMIN2=TMIN2,
                                   TMIN3=TMIN3, TMIN4=TMIN4, TMAX1=TMAX1,
                                   TMAX2=TMAX2, TMAX3=TMAX3, TMAX4=TMAX4,
                                   DIF5=DIF5, DIF6=DIF6, need_day_number=need_day_number)
        result = np.append(result, [temp],axis=0)
    print("prediction ends")
    result_max=[]
    for i in range(result.shape[0]):
        result_max.append(result[i,day-1])
    print("interpolation starts...")
    # create interpolation map and show map
    vint_reclass = interpolation(result_max, xy, year, day)

    i,j=np.where(vint_reclass==3)
    high=[(abs((j[counter]*0.0005)-b), (i[counter]*0.0005)+a) for counter in range(len(i))]

    i,j=np.where(vint_reclass==2)
    medium=[(abs((j[counter]*0.0005)-b), (i[counter]*0.0005)+a) for counter in range(len(i))]

    i,j=np.where(vint_reclass==1)
    low=[(abs((j[counter]*0.0005)-b), (i[counter]*0.0005)+a) for counter in range(len(i))]

    print("low len", len(low))
    print("medium len", len(medium))
    print("high len", len(high))
    print("no effect", len(vint_reclass[vint_reclass==0]))

    print("interpolation ends")

    return high, medium, low
