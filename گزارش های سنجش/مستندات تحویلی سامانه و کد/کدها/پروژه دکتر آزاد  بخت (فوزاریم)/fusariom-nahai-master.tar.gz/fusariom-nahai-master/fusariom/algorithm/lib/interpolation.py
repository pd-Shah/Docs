import numpy as np
import math
import matplotlib.pyplot as plt
from .IDW_neighborhood import IDW_neighbourhood

'''
% this function create map by IDW interpolation method
'''
def interpolation(result_max, xy,day,year):
    result_max=np.array(result_max)
    result_max=result_max.reshape([xy.shape[0],1])
    #calculate prediction value
    input_=np.hstack((xy,result_max))
    xc=input_[:,0]
    yc=input_[:,1]
    vc=input_[:,2]
    # 0.0002 distance for interpolation map (0.5 is degree:boundary border)
    x=np.arange(np.min(xc)-0.5,np.max(xc)+0.5,0.002)
    y=np.arange(np.min(yc)-0.5,np.max(yc)+0.5,0.002)
    # power, integer
    e=2
    # number of point for interpolation
    r1=3
    # max radius for interpolation
    r2=0.005
    # output array
    vint=np.zeros(shape=(len(y),len(x)))
    for i in range(len(x)):
        for j in range(len(y)):
            V=np.array([])
            wV=np.array([])
            vcc=np.array([])
            # calculate distance between points
            D=np.sqrt((xc-x[i])**2+(yc-y[j])**2)
            # put vc in vcc if r2>D
            vcc=vc[r2>D]
            # if exist minimum 4 point with distance lower r2, calculate Vint
            if int(vcc.shape[0])>r1+1:
                D=D[D<r2]
                V=vcc/D**math.e
                wV=1/D**math.e
                V=np.sum(V)/np.sum(wV)
                vint[j,i]=V
            else:
                vint=IDW_neighbourhood(D,vint,vcc, wV,V,vc,e,r1,j,i)
     # create reclass
    vint_reclass=np.zeros_like(vint)
    for i in range(np.shape(vint)[0]):
        for j in range(np.shape(vint)[1]):
            if vint[i,j]<15:
                vint_reclass[i,j]=1
            elif vint[i,j]>=15 and vint[i,j]<25:
                vint_reclass[i,j]=2
            else :
                vint_reclass[i,j]=3

    return vint_reclass
