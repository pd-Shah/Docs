from django.shortcuts import render, get_list_or_404
from django.views import generic
from django.core.urlresolvers import reverse
from . import models
from fusariom.models import region
from .algorithm import main
from django.http import HttpResponse
import json
# from fusariom.lib import main

def index(request ):
    context={'high': None,
             'medium': None,
             'low': None,
    }

    if request.method=='POST':
        year=request.POST.get("year")
        day=request.POST.get("day")
        # selected_obj=region.objects.filter(year=year)[0]
        selected_obj=get_list_or_404(region, year=year)[0]
        high, medium, low = main.main(c1=8.86,
                    c3=28.97,
                    c4=23.23,
                    c5=18.27,
                    c6=20.67,
                    time1=0,
                    st1=1,
                    RH1=78,
                    RH2=78,
                    RH3=75,
                    RH4=78,
                    RN1=5,
                    RN2=5,
                    TMIN1=9,
                    TMAX1=25,
                    TMIN2=15,
                    TMAX2=30,
                    TMIN3=9,
                    TMAX3=25,
                    TMIN4=15,
                    TMAX4=30,
                    DIF5=10,
                    DIF6=15,
                    a=47.551789,
                    b=39.610247,
                    year=year,
                    day=day,
                    data=selected_obj.data,
                    xy=selected_obj.lat_long_station,
                    )
        context={
            'high':json.dumps(high),
            'medium':json.dumps(medium),
            'low':json.dumps(low),
        }


    return render(request, template_name="fusariom/index.html", context=context)
