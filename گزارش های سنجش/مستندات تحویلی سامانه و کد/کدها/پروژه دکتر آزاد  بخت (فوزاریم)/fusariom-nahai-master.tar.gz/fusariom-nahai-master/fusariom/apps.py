from django.apps import AppConfig


class FusariomConfig(AppConfig):
    name = 'fusariom'
