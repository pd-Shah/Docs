from django.db import models
from django.urls import reverse
from django.contrib.postgres.fields import JSONField



class region(models.Model):
    regionname=models.CharField(max_length=250, help_text="enter city name")
    choice=[('1389',"1389"),
                ('1390',"1390"),
                ('1391',"1391"),
                ('1392',"1392"),
                ('1393',"1393"),
                ('1394',"1394"),
                ('1395',"1395"),
                ('1396',"1396"),
                ('1397',"1397"),]
    # choices=[(0,"1"),
    #             (1,"2"),
    #             (2,"3"),
    #             (3,"4"),
    #             (4,"5"),
    #             (5,"6"),
    #             (6,"7"),
    #             (7,"8"),
    #             (8,"9"),
    #             (9,"10"),
    #             (10,"11"),
    #             (11,"12"),
    #             (12,"13"),
    #             (13,"14"),
    #             (14,"15"),
    #             (15,"16")]
    year=models.CharField(max_length=300, help_text="select a year ",choices=choice, unique=True)
    data=JSONField(default={})
    lat_long_station=JSONField(default={})
    # top_left_lat_long=JSONField(default={})
    # day=models.CharField(max_length=250, help_text="یک روز را انتخاب کنید", choices=choices)
    def __str__(self):
        return self.regionname
