from django.apps import AppConfig


class CropdetectionConfig(AppConfig):
    name = 'cropdetection'
