from ..base import AzarbayjanGharbiBase


class Khoy(AzarbayjanGharbiBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
