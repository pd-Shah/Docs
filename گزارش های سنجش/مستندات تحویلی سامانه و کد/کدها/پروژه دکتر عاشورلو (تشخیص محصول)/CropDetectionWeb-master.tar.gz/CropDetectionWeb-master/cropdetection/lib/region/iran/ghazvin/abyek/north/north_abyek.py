from ...base import GhazvinBase


class NorthAbyek(GhazvinBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
