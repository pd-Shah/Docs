from ..base import ArdebilBase


class Sarin(ArdebilBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
