from ...base import ArdebilBase


class SouthMeshkinShahr(ArdebilBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
