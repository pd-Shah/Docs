from ..base import GhazvinBase


class WestGhazvin(GhazvinBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
