from ...base import GhazvinBase


class WestBoinZahra(GhazvinBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
