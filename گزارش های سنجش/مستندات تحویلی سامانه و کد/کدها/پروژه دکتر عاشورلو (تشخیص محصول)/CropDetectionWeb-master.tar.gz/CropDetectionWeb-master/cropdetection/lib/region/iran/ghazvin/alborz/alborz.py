from ..base import GhazvinBase


class Alborz(GhazvinBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
