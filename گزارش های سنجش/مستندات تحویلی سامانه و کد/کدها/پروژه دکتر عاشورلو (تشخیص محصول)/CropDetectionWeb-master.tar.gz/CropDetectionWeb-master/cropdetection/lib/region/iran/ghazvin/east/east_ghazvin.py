from ..base import GhazvinBase


class EastGhazvin(GhazvinBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
