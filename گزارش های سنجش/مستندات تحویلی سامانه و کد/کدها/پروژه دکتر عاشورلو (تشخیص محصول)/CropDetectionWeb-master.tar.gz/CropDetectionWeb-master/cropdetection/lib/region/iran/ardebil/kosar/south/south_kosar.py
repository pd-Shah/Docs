from ...base import ArdebilBase


class SouthKosar(ArdebilBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
