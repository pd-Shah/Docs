from ...base import ArdebilBase


class NorthMeshkinShahr(ArdebilBase):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
