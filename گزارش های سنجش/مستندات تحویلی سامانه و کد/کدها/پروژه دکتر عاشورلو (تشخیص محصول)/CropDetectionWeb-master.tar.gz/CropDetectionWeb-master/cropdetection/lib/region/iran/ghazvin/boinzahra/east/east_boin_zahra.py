from ...base import GhazvinBase


class EastBoinZahra(GhazvinBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
