from ...base import ArdebilBase


class NorthKosar(ArdebilBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
